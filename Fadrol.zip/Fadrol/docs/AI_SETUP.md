# Konfigurasi AI

Informasi model dan App Check di bawah ini berasal dari dokumentasi Firebase AI Logic yang dibaca pada 18 Oktober 2026. Periksa ulang karena bisa berubah.

## Jalur 1: API key sendiri (tanpa Firebase)

1. Buat API key di Google AI Studio.
2. Fadrol > Pengaturan > AI > Sumber AI: **API key sendiri**.
3. Tempel key, tekan **Simpan**. Key dienkripsi dengan AES-GCM, kunci enkripsinya ada di Android Keystore, dan tidak pernah masuk ke APK atau repositori.
4. Tekan **Tes koneksi AI**. Status di layar utama berubah setelah satu jawaban berhasil diterima.

Catatan: ini cocok untuk penggunaan pribadi. Untuk aplikasi yang disebarkan ke banyak orang, jangan minta pengguna menaruh key bersama; pakai Firebase AI Logic atau backend sendiri yang mengatur kredensial dan batas pemakaian.

## Jalur 2: Firebase AI Logic (Gemini Developer API)

1. Buat proyek di Firebase Console.
2. Tambahkan aplikasi Android dengan package `com.fadrol.ai`. Tambahkan sidik jari SHA-256 jika memakai Play Integrity.
3. Unduh `google-services.json` dan taruh di `app/google-services.json`. Berkas ini sudah ada di `.gitignore`. Plugin Google Services hanya aktif bila berkas itu ada.
4. Firebase Console > **AI Logic** > Get started > pilih **Gemini Developer API**. Model default aplikasi: `gemini-3.5-flash`.
5. **App Check.** Menurut dokumentasi, wizard AI Logic sejak Juli 2026 memberlakukan App Check otomatis, dan App Check wajib untuk Firebase AI Logic mulai 2 November 2026.
   - Build release memakai provider **Play Integrity** (aplikasi harus dikenali Google Play; APK yang dipasang manual akan ditolak).
   - Build debug memakai provider **debug**. Buka Fadrol (build debug) > Pengaturan > AI > *Token debug App Check* > Tampilkan token, lalu daftarkan di Firebase Console > App Check > Apps > Manage debug tokens.
6. Bangun ulang aplikasi, pilih **Firebase AI Logic** di Pengaturan, lalu **Tes koneksi AI**.

### Model

Nama model bisa diganti di Pengaturan tanpa membangun ulang. Menurut halaman model Firebase AI Logic (diperbarui 16 Okt 2026): `gemini-3.5-flash` stabil dan tersedia untuk Gemini Developer API; `gemini-2.5-flash` dibatasi untuk proyek yang sebelumnya sudah aktif memakainya sehingga tidak dipakai sebagai default; model baru seperti `gemini-3.8-flash` berstatus ketersediaan jangka pendek. Pilih sesuai kebutuhan dan cek halaman model saat versi berubah.

## Keamanan

- Tidak ada API key rahasia di dalam APK. Pemeriksaan otomatis mencari pola key Google di seluruh proyek.
- Semua koneksi memakai HTTPS (`usesCleartextTraffic` tidak diaktifkan).
- Screenshot dan gambar hanya dikirim setelah pengguna menekan konfirmasi, dan tidak ditulis ke disk. Foto kamera disimpan sementara di cache dan langsung dihapus setelah dibaca.
