# Laporan pengujian

Tanggal: 18 Oktober 2026. Lingkungan: Linux tanpa Android SDK, Gradle, kompiler Kotlin, perangkat/emulator, atau internet.

**Kesimpulan: kode belum dikompilasi, APK belum dibuat, dan tidak ada fitur yang sudah diuji di perangkat.** Yang dilakukan hanyalah pemeriksaan statis dan verifikasi algoritma.

## Yang sudah dijalankan

| Pemeriksaan | Hasil |
|---|---|
| Pemeriksaan statis 49 berkas Kotlin (skrip `check/static_check.py` di sesi pembuatan): kurung seimbang, impor antar-berkas di proyek, impor simbol Compose/AndroidX/kotlinx/Android yang umum, ikon hanya dari `material-icons-core`, resource `R.*` dan `@...` ada, kelas di manifest ada, tipe foreground service benar, izin wajib ada | Lolos setelah memperbaiki 1 impor `getValue` yang hilang |
| XML (manifest, drawable, mipmap, values, xml) divalidasi dengan `xmllint` | Lolos |
| String Indonesia dan Inggris: 231 kunci, tidak ada yang hilang, argumen format (`%1$s`, `%1$d`) sama di kedua bahasa | Lolos |
| Pencarian API key tertanam di seluruh proyek | Tidak ditemukan |
| Algoritma Target nilai diuji dengan cermin Python: semua contoh dari spesifikasi (20 soal, target 80 butuh 16 benar; tabel 100/90/80/70/60) dan 400 kasus acak dibandingkan dengan brute force semua kombinasi | Lolos setelah memperbaiki 2 kasus batas: penalti bersama nilai awal (kebutuhan bisa negatif) dan target 0 |

Catatan penting: cermin Python menguji **rancangan algoritma**, bukan kode Kotlin. Kode Kotlin-nya ditulis dengan logika yang sama, dan 16 unit test Kotlin sudah ditulis (`app/src/test/.../TargetScoreCalculatorTest.kt`), tetapi **belum dijalankan**.

## Yang belum dijalankan

Kompilasi, unit test Kotlin, instalasi APK, dan semua pengujian di perangkat. Jalankan checklist di bawah pada perangkat Android 8.0 ke atas, idealnya satu perangkat Android 14 atau lebih baru (batasan foreground service dan MediaProjection paling ketat di sana).

## Checklist 20 pengujian wajib

Status semua baris: **belum diuji** (kecuali yang tertulis lain).

| # | Pengujian | Cara menguji |
|---|---|---|
| 1 | Aplikasi dibuka tanpa crash | Pasang APK, buka. |
| 2 | Splash dan Home tampil benar | Cek logo, nama Fadrol, baris menu, tema gelap dan terang. |
| 3 | Ikon mengambang tampil setelah izin diberikan | Home > Ikon mengambang > aktifkan > beri izin overlay > aktifkan lagi. |
| 4 | Ikon bisa digeser dan disembunyikan | Geser ke dua sisi (harus menempel), putar layar, lalu Sembunyikan ikon lewat notifikasi atau menu panel. |
| 5 | Panel bisa dibuka dan ditutup | Ketuk ikon; uji minimalkan, perbesar, tutup, tombol Kembali. |
| 6 | AI menjawab pertanyaan teks | Atur AI (lihat docs/AI_SETUP.md), Tes koneksi AI, lalu tanya soal di AI Chat dan di panel. |
| 7 | AI menganalisis gambar | Kirim foto soal lewat Analisis gambar; pastikan ada konfirmasi sebelum kirim. |
| 8 | OCR membaca teks yang jelas | Scan gambar teks jelas; cek urutan nomor soal dan pilihan jawaban. |
| 9 | Screenshot membutuhkan persetujuan | Baca soal di layar; dialog sistem harus muncul, dan tanpa persetujuan tidak ada gambar. |
| 10 | Penolakan izin ditangani | Tolak izin overlay, notifikasi, dan tangkap layar; aplikasi tidak boleh crash dan harus memberi pesan. |
| 11 | Target nilai bisa diatur 0 sampai 100 | Coba 0, 60, 85, 100, dan nilai di luar rentang (harus ada pesan galat). |
| 12 | Perhitungan Target nilai akurat | 20 soal target 80 harus butuh 16 benar. Jalankan juga `./gradlew testDebugUnitTest`. |
| 13 | Bobot berbeda dihitung benar | Bobot `1 2 3 4`, target 70: paling sedikit 2 benar, 4 benar pasti cukup. |
| 14 | Simulasi benar dan salah berjalan | Ketuk nomor soal dan pakai tombol +/− (bobot sama). |
| 15 | Nilai berubah saat input diperbarui | Ubah target, jumlah soal, penalti, nilai awal; skor dan cincin harus berubah langsung. |
| 16 | Target mustahil ditangani | 10 soal, target 90, tandai 2 salah: harus muncul penjelasan nilai maksimum 80. |
| 17 | Riwayat tersimpan dan terhapus | Kirim pesan, buka Riwayat, cari, buka, hapus satu, hapus semua; matikan "Simpan riwayat" lalu pastikan tidak tersimpan. |
| 18 | Galat jaringan tampil benar | Matikan internet lalu kirim pesan; harus muncul pesan jaringan. |
| 19 | Floating service bisa dihentikan | Dari saklar di aplikasi, tombol Hentikan di notifikasi, dan menu panel. |
| 20 | APK terpasang di perangkat sasaran | Pasang di perangkat nyata; uji juga rotasi layar dan keyboard di panel. |

## Titik risiko yang perlu perhatian saat uji pertama

1. **Kompilasi.** Kode ditulis tanpa kompiler. Bila Gradle melaporkan galat, kemungkinan terbesar ada di tanda tangan API Compose/Firebase (lihat `FirebaseGeminiService.kt`, `FloatingService.kt`, `ui/components`).
2. **Compose di jendela overlay.** Memakai `OverlayLifecycleOwner` agar `ComposeView` punya lifecycle, ViewModelStore, dan SavedStateRegistry.
3. **Keyboard di panel.** `SOFT_INPUT_ADJUST_RESIZE` pada overlay tidak seragam antar perangkat.
4. **Android 14+.** Foreground service `specialUse` dan `mediaProjection`, serta pendaftaran callback sebelum `createVirtualDisplay`.
5. **Latar belakang.** Memulai Activity dari service mengandalkan overlay yang sedang tampil; bila perangkat memblokirnya, gunakan tombol dari dalam aplikasi.
