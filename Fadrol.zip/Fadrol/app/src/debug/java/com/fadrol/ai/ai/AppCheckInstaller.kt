package com.fadrol.ai.ai

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory

/** Build debug: App Check memakai provider debug. Token-nya harus didaftarkan sekali di Firebase Console. */
object AppCheckInstaller {

    fun install(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) return
            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(DebugAppCheckProviderFactory.getInstance())
        } catch (e: Throwable) {
            // Firebase belum dikonfigurasi atau provider tidak tersedia; AI lewat API key sendiri tetap jalan.
        }
    }

    /** Memicu provider debug membuat token-nya (aman dipanggil berulang). */
    fun warmUp() {
        try {
            FirebaseAppCheck.getInstance().getAppCheckToken(false)
        } catch (e: Throwable) {
            // diabaikan
        }
    }

    /** Token debug yang tersimpan oleh provider, atau null bila belum dibuat. */
    fun debugToken(context: Context): String? = try {
        val app = FirebaseApp.getInstance()
        context.getSharedPreferences(
            "com.google.firebase.appcheck.debug.store." + app.persistenceKey,
            Context.MODE_PRIVATE,
        ).getString("com.google.firebase.appcheck.debug.DEBUG_SECRET", null)
    } catch (e: Throwable) {
        null
    }
}
