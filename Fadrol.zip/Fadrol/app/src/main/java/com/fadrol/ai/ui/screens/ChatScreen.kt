@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.screens

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.fadrol.ai.R
import com.fadrol.ai.appContainer
import com.fadrol.ai.chat.ChatViewModel
import com.fadrol.ai.ui.components.ChatBody
import com.fadrol.ai.ui.components.rememberImagePickers
import com.fadrol.ai.ui.components.rememberScreenReadAction

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversationId: Long,
    onBack: () -> Unit,
    onOpenTarget: () -> Unit,
    onOpenHistory: () -> Unit,
) {
    val context = LocalContext.current
    val container = remember { context.appContainer() }
    val vm: ChatViewModel = viewModel(factory = viewModelFactory { initializer { ChatViewModel(container) } })
    val controller = vm.controller
    val pickers = rememberImagePickers { bitmap -> controller.attachImage(bitmap) }
    val readScreen = rememberScreenReadAction()
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(conversationId) {
        if (conversationId > 0) controller.open(conversationId)
    }
    LaunchedEffect(Unit) { vm.consumePending() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.chat_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    IconButton(onClick = onOpenTarget) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = stringResource(R.string.chat_action_target))
                    }
                    IconButton(onClick = onOpenHistory) {
                        Icon(Icons.Filled.DateRange, contentDescription = stringResource(R.string.chat_history))
                    }
                    IconButton(onClick = controller::newConversation) {
                        Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.chat_new))
                    }
                    if (controller.conversationId != null) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.chat_delete))
                        }
                    }
                },
            )
        },
    ) { padding ->
        ChatBody(
            controller = controller,
            onPickGallery = pickers.gallery,
            onPickCamera = pickers.camera,
            modifier = Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding(),
            onReadScreen = readScreen,
            onTargetScore = onOpenTarget,
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.chat_delete_confirm_title)) },
            text = { Text(stringResource(R.string.chat_delete_confirm_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    controller.deleteCurrent()
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
