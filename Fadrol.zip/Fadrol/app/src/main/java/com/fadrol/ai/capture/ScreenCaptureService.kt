package com.fadrol.ai.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.fadrol.ai.R
import com.fadrol.ai.ocr.ImageUtils
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout

/**
 * Mengambil SATU frame layar setelah pengguna menyetujui dialog sistem, lalu berhenti dan melepas semua resource.
 * Tidak ada perekaman terus-menerus, dan gambar tidak ditulis ke disk.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_DELAY_MS = "delay_ms"
        private const val CHANNEL_ID = "fadrol_capture"
        private const val NOTIF_ID = 1002

        /** Jeda sebelum frame diambil, setelah overlay Fadrol disembunyikan. */
        private const val HIDE_OVERLAY_MS = 700L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNow()
        val data: Intent? = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_RESULT_DATA, Intent::class.java) }
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val delayMs = intent?.getLongExtra(EXTRA_DELAY_MS, 900L) ?: 900L
        if (data == null || code != Activity.RESULT_OK) {
            CaptureCoordinator.emit(CaptureEvent.Cancelled)
            finishUp()
            return START_NOT_STICKY
        }
        job?.cancel()
        job = scope.launch { runCapture(code, data, delayMs) }
        return START_NOT_STICKY
    }

    private suspend fun runCapture(code: Int, data: Intent, delayMs: Long) {
        try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            val proj = manager.getMediaProjection(code, data) ?: throw IllegalStateException("MediaProjection null")
            projection = proj
            // Android 14+ mewajibkan callback terdaftar sebelum membuat VirtualDisplay.
            proj.registerCallback(
                object : MediaProjection.Callback() {
                    override fun onStop() {
                        handler.post { releaseCapture() }
                    }
                },
                handler,
            )
            delay((delayMs - HIDE_OVERLAY_MS).coerceAtLeast(0L))
            CaptureCoordinator.emit(CaptureEvent.Capturing)
            delay(HIDE_OVERLAY_MS)
            val frame = withTimeout(6_000L) { grabFrame(proj) }
            val bitmap = ImageUtils.downscale(frame, 2200)
            CaptureCoordinator.emit(CaptureEvent.Captured(bitmap, ImageUtils.isMostlyBlank(bitmap)))
        } catch (e: TimeoutCancellationException) {
            CaptureCoordinator.emit(CaptureEvent.Failed(CaptureFailure.TIMEOUT))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CaptureCoordinator.emit(CaptureEvent.Failed(CaptureFailure.ERROR))
        } finally {
            finishUp()
        }
    }

    private suspend fun grabFrame(proj: MediaProjection): Bitmap = suspendCancellableCoroutine { cont ->
        val (width, height, dpi) = displayInfo()
        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader = imageReader
        imageReader.setOnImageAvailableListener(
            { r ->
                val image = try {
                    r.acquireLatestImage()
                } catch (e: Exception) {
                    null
                }
                if (image != null) {
                    try {
                        val bitmap = imageToBitmap(image, width, height)
                        r.setOnImageAvailableListener(null, null)
                        if (cont.isActive) cont.resume(bitmap)
                    } catch (e: Throwable) {
                        if (cont.isActive) cont.resumeWithException(e)
                    } finally {
                        image.close()
                    }
                }
            },
            handler,
        )
        display = proj.createVirtualDisplay(
            "fadrol-capture",
            width,
            height,
            dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface,
            null,
            handler,
        )
    }

    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        if (padded.width == width) return padded
        val exact = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return exact
    }

    @Suppress("DEPRECATION")
    private fun displayInfo(): Triple<Int, Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dpi = resources.displayMetrics.densityDpi
        return if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.currentWindowMetrics.bounds
            Triple(bounds.width(), bounds.height(), dpi)
        } else {
            val metrics = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(metrics)
            Triple(metrics.widthPixels, metrics.heightPixels, dpi)
        }
    }

    private fun releaseCapture() {
        try {
            display?.release()
        } catch (e: Exception) {
            // sudah dilepas
        }
        display = null
        try {
            reader?.setOnImageAvailableListener(null, null)
            reader?.close()
        } catch (e: Exception) {
            // sudah ditutup
        }
        reader = null
        val p = projection
        projection = null
        try {
            p?.stop()
        } catch (e: Exception) {
            // sudah berhenti
        }
    }

    private fun finishUp() {
        releaseCapture()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        releaseCapture()
        super.onDestroy()
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.capture_channel), NotificationManager.IMPORTANCE_LOW),
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_fadrol_mark)
            .setContentTitle(getString(R.string.capture_notif_title))
            .setContentText(getString(R.string.capture_notif_text))
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }
}
