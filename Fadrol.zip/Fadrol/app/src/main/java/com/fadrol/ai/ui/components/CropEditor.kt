@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.fadrol.ai.R
import com.fadrol.ai.ocr.ImageUtils
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private enum class DragMode { NONE, MOVE, TL, TR, BL, BR, L, R, T, B }

private const val MIN_SIZE = 0.08f

private fun pickMode(p: Offset, rect: Rect, offX: Float, offY: Float, imgW: Float, imgH: Float, hit: Float): DragMode {
    val l = offX + rect.left * imgW
    val t = offY + rect.top * imgH
    val r = offX + rect.right * imgW
    val b = offY + rect.bottom * imgH
    val nearL = abs(p.x - l) < hit
    val nearR = abs(p.x - r) < hit
    val nearT = abs(p.y - t) < hit
    val nearB = abs(p.y - b) < hit
    val inX = p.x >= l - hit && p.x <= r + hit
    val inY = p.y >= t - hit && p.y <= b + hit
    return when {
        nearL && nearT -> DragMode.TL
        nearR && nearT -> DragMode.TR
        nearL && nearB -> DragMode.BL
        nearR && nearB -> DragMode.BR
        nearL && inY -> DragMode.L
        nearR && inY -> DragMode.R
        nearT && inX -> DragMode.T
        nearB && inX -> DragMode.B
        p.x >= l && p.x <= r && p.y >= t && p.y <= b -> DragMode.MOVE
        else -> DragMode.NONE
    }
}

/** Menggeser kotak pangkas. Koordinat dalam pecahan 0..1 dari gambar. */
private fun dragRect(rect: Rect, mode: DragMode, dx: Float, dy: Float): Rect {
    var l = rect.left
    var t = rect.top
    var r = rect.right
    var b = rect.bottom
    when (mode) {
        DragMode.NONE -> return rect
        DragMode.MOVE -> {
            val w = r - l
            val h = b - t
            l = (l + dx).coerceIn(0f, 1f - w)
            t = (t + dy).coerceIn(0f, 1f - h)
            r = l + w
            b = t + h
        }
        DragMode.TL -> {
            l = (l + dx).coerceIn(0f, r - MIN_SIZE)
            t = (t + dy).coerceIn(0f, b - MIN_SIZE)
        }
        DragMode.TR -> {
            r = (r + dx).coerceIn(l + MIN_SIZE, 1f)
            t = (t + dy).coerceIn(0f, b - MIN_SIZE)
        }
        DragMode.BL -> {
            l = (l + dx).coerceIn(0f, r - MIN_SIZE)
            b = (b + dy).coerceIn(t + MIN_SIZE, 1f)
        }
        DragMode.BR -> {
            r = (r + dx).coerceIn(l + MIN_SIZE, 1f)
            b = (b + dy).coerceIn(t + MIN_SIZE, 1f)
        }
        DragMode.L -> l = (l + dx).coerceIn(0f, r - MIN_SIZE)
        DragMode.R -> r = (r + dx).coerceIn(l + MIN_SIZE, 1f)
        DragMode.T -> t = (t + dy).coerceIn(0f, b - MIN_SIZE)
        DragMode.B -> b = (b + dy).coerceIn(t + MIN_SIZE, 1f)
    }
    return Rect(l, t, r, b)
}

/** Pemangkas gambar: geser sudut/sisi kotak, putar 90 derajat, atur ulang. Dipakai di halaman Scan dan panel mengambang. */
@Composable
fun CropEditor(
    bitmap: Bitmap,
    onConfirm: (Bitmap) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    blockedWarning: Boolean = false,
) {
    var working by remember(bitmap) { mutableStateOf(bitmap) }
    var rect by remember(working) { mutableStateOf(Rect(0f, 0f, 1f, 1f)) }
    var dragMode by remember { mutableStateOf(DragMode.NONE) }
    val density = LocalDensity.current
    val accent = MaterialTheme.colorScheme.primary
    val image = remember(working) { working.asImageBitmap() }

    Column(modifier) {
        if (blockedWarning) {
            Text(
                text = stringResource(R.string.capture_blocked_warning),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
        Text(
            text = stringResource(R.string.scan_crop_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
        )
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(8.dp),
        ) {
            val boxW = constraints.maxWidth.toFloat()
            val boxH = constraints.maxHeight.toFloat()
            val scale = min(boxW / working.width, boxH / working.height)
            val imgW = working.width * scale
            val imgH = working.height * scale
            val offX = (boxW - imgW) / 2f
            val offY = (boxH - imgH) / 2f
            val hit = with(density) { 36.dp.toPx() }

            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(working, boxW, boxH) {
                        detectDragGestures(
                            onDragStart = { p -> dragMode = pickMode(p, rect, offX, offY, imgW, imgH, hit) },
                            onDragEnd = { dragMode = DragMode.NONE },
                            onDragCancel = { dragMode = DragMode.NONE },
                            onDrag = { change, delta ->
                                change.consume()
                                rect = dragRect(rect, dragMode, delta.x / imgW, delta.y / imgH)
                            },
                        )
                    },
            ) {
                drawImage(
                    image,
                    dstOffset = IntOffset(offX.roundToInt(), offY.roundToInt()),
                    dstSize = IntSize(imgW.roundToInt(), imgH.roundToInt()),
                )
                val l = offX + rect.left * imgW
                val t = offY + rect.top * imgH
                val r = offX + rect.right * imgW
                val b = offY + rect.bottom * imgH
                val dim = Color.Black.copy(alpha = 0.55f)
                drawRect(dim, Offset(offX, offY), Size(imgW, t - offY))
                drawRect(dim, Offset(offX, b), Size(imgW, offY + imgH - b))
                drawRect(dim, Offset(offX, t), Size(l - offX, b - t))
                drawRect(dim, Offset(r, t), Size(offX + imgW - r, b - t))
                drawRect(accent, Offset(l, t), Size(r - l, b - t), style = Stroke(width = 2.dp.toPx()))
                val radius = 7.dp.toPx()
                drawCircle(accent, radius, Offset(l, t))
                drawCircle(accent, radius, Offset(r, t))
                drawCircle(accent, radius, Offset(l, b))
                drawCircle(accent, radius, Offset(r, b))
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = { working = ImageUtils.rotate(working, 90) }) {
                Text(stringResource(R.string.scan_rotate))
            }
            TextButton(onClick = { rect = Rect(0f, 0f, 1f, 1f) }) {
                Text(stringResource(R.string.scan_reset))
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onCancel) { Text(stringResource(R.string.scan_cancel)) }
            Button(onClick = {
                val w = working.width
                val h = working.height
                onConfirm(
                    ImageUtils.crop(
                        working,
                        (rect.left * w).roundToInt(),
                        (rect.top * h).roundToInt(),
                        (rect.right * w).roundToInt(),
                        (rect.bottom * h).roundToInt(),
                    ),
                )
            }) {
                Text(stringResource(R.string.scan_crop_confirm))
            }
        }
    }
}
