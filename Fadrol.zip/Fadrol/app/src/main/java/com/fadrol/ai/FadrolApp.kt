package com.fadrol.ai

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import com.fadrol.ai.ai.AppCheckInstaller
import com.fadrol.ai.settings.toNightMode
import kotlinx.coroutines.runBlocking

class FadrolApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // Terapkan tema pilihan pengguna sebelum Activity dibuat supaya tidak ada kedipan terang/gelap.
        val theme = runBlocking { container.settings.snapshot().theme }
        AppCompatDelegate.setDefaultNightMode(theme.toNightMode())
        AppCheckInstaller.install(this)
    }
}

fun Context.appContainer(): AppContainer = (applicationContext as FadrolApp).container
