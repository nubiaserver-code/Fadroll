package com.fadrol.ai.targetscore

import androidx.annotation.StringRes
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.fadrol.ai.AppContainer
import com.fadrol.ai.R
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.ai.Prompts
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

sealed interface ConfigResult {
    class Ok(val config: ScoreConfig) : ConfigResult

    class Invalid(@StringRes val message: Int) : ConfigResult
}

/**
 * State fitur Target nilai. Dipakai oleh halaman Target nilai (di dalam ViewModel) dan oleh panel mengambang
 * (dipegang service), sehingga kedua tampilan memakai logika perhitungan yang sama.
 * Seluruh angka skor dihitung oleh [TargetScoreCalculator], bukan oleh model bahasa.
 */
class TargetScoreState(
    private val container: AppContainer,
    private val scope: CoroutineScope,
) {
    var targetText by mutableStateOf("80")
    var countText by mutableStateOf("20")
    var customWeights by mutableStateOf(false)
    var weightsText by mutableStateOf("")
    var initialText by mutableStateOf("")
    var penaltyText by mutableStateOf("")
    var practiceMode by mutableStateOf(false)
    var practiceText by mutableStateOf("")

    val states = mutableStateListOf<AnswerState>().also { list ->
        repeat(20) { list.add(AnswerState.UNANSWERED) }
    }

    var evaluating by mutableStateOf(false)
        private set
    var evaluation by mutableStateOf<EvalResult?>(null)
        private set
    var evalError by mutableStateOf<Throwable?>(null)
        private set
    var evalParseFailed by mutableStateOf(false)
        private set

    /** Teks OCR terakhir dari fitur Scan / Baca soal di layar, bila ada. */
    val lastOcrText: StateFlow<String?> get() = container.lastOcrText

    val correctCount: Int get() = states.count { it == AnswerState.CORRECT }
    val wrongCount: Int get() = states.count { it == AnswerState.WRONG }

    fun parse(): ConfigResult {
        val target = targetText.replace(',', '.').toDoubleOrNull()
        if (target == null || target < 0.0 || target > 100.0) return ConfigResult.Invalid(R.string.ts_err_target)

        val initial = if (initialText.isBlank()) 0.0 else initialText.replace(',', '.').toDoubleOrNull()
        if (initial == null || initial < 0.0 || initial > 100.0) return ConfigResult.Invalid(R.string.ts_err_initial)

        val penaltyPercent = if (penaltyText.isBlank()) 0.0 else penaltyText.replace(',', '.').toDoubleOrNull()
        if (penaltyPercent == null || penaltyPercent < 0.0 || penaltyPercent > 100.0) {
            return ConfigResult.Invalid(R.string.ts_err_penalty)
        }

        val weights: List<Double> = if (customWeights) {
            TargetScoreCalculator.parseWeights(weightsText) ?: return ConfigResult.Invalid(R.string.ts_err_weights)
        } else {
            val n = countText.toIntOrNull()
            if (n == null || n !in 1..TargetScoreCalculator.MAX_QUESTIONS) return ConfigResult.Invalid(R.string.ts_err_count)
            TargetScoreCalculator.equalWeights(n)
        }
        return ConfigResult.Ok(ScoreConfig(target, weights, initial, penaltyPercent / 100.0))
    }

    // --- Perubahan input: jaga daftar jawaban selalu sama panjang dengan jumlah soal ---

    fun onTargetChange(value: String) {
        targetText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(6)
    }

    fun onInitialChange(value: String) {
        initialText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(6)
    }

    fun onPenaltyChange(value: String) {
        penaltyText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(6)
    }

    fun onCountChange(value: String) {
        countText = value.filter { it.isDigit() }.take(3)
        syncStates()
    }

    fun onWeightsChange(value: String) {
        weightsText = value
        syncStates()
    }

    fun onCustomToggle(enabled: Boolean) {
        if (enabled && weightsText.isBlank()) {
            val n = (countText.toIntOrNull() ?: states.size).coerceIn(1, TargetScoreCalculator.MAX_QUESTIONS)
            weightsText = List(n) { "1" }.joinToString(" ")
        }
        if (!enabled) countText = states.size.coerceAtLeast(1).toString()
        customWeights = enabled
        syncStates()
    }

    fun syncStates() {
        val n = (parse() as? ConfigResult.Ok)?.config?.count ?: return
        while (states.size < n) states.add(AnswerState.UNANSWERED)
        while (states.size > n) states.removeAt(states.lastIndex)
    }

    // --- Simulasi benar dan salah ---

    fun cycle(index: Int) {
        if (index !in states.indices) return
        states[index] = when (states[index]) {
            AnswerState.UNANSWERED -> AnswerState.CORRECT
            AnswerState.CORRECT -> AnswerState.WRONG
            AnswerState.WRONG -> AnswerState.UNANSWERED
        }
    }

    fun setCounts(correct: Int, wrong: Int) {
        val n = states.size
        val c = correct.coerceIn(0, n)
        val w = wrong.coerceIn(0, n - c)
        for (i in 0 until n) {
            states[i] = if (i < c) {
                AnswerState.CORRECT
            } else if (i < c + w) {
                AnswerState.WRONG
            } else {
                AnswerState.UNANSWERED
            }
        }
    }

    fun resetAnswers() {
        for (i in states.indices) states[i] = AnswerState.UNANSWERED
    }

    // --- Mode latihan ---

    fun useLastOcr() {
        val text = container.lastOcrText.value ?: return
        practiceText = if (practiceText.isBlank()) text else practiceText.trimEnd() + "\n\n" + text
        practiceMode = true
    }

    fun discussPrompt(): String = container.app.getString(R.string.ts_discuss_prompt, practiceText.trim())

    /** AI menilai tiap nomor (jawaban benar + apakah jawaban pengguna benar); program yang menghitung skornya. */
    fun evaluate() {
        val text = practiceText.trim()
        if (text.isEmpty() || evaluating) return
        evaluating = true
        evalError = null
        evalParseFailed = false
        evaluation = null
        scope.launch {
            try {
                val raw = container.aiRepository.askJson(Prompts.EVALUATION_SYSTEM, text)
                val parsed = EvalParser.parse(raw)
                if (parsed == null || parsed.items.isEmpty()) {
                    evalParseFailed = true
                } else {
                    evaluation = parsed
                    applyEvaluation(parsed)
                    saveToHistory(text, parsed)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                evalError = e
            } finally {
                evaluating = false
            }
        }
    }

    private fun applyEvaluation(result: EvalResult) {
        if (!customWeights) countText = result.items.size.coerceIn(1, TargetScoreCalculator.MAX_QUESTIONS).toString()
        syncStates()
        for ((index, item) in result.items.withIndex()) {
            if (index >= states.size) break
            states[index] = when (item.isCorrect) {
                true -> AnswerState.CORRECT
                false -> AnswerState.WRONG
                null -> AnswerState.UNANSWERED
            }
        }
    }

    private suspend fun saveToHistory(question: String, result: EvalResult) {
        if (!container.settings.snapshot().saveHistory) return
        val config = (parse() as? ConfigResult.Ok)?.config
        val firstLine = question.lineSequence().firstOrNull().orEmpty().take(36)
        val id = container.chatRepository.create(
            title = container.app.getString(R.string.ts_history_title, firstLine),
            source = "target",
            mode = AnswerMode.FULL,
            targetJson = config?.let { snapshotJson(it) },
        )
        container.chatRepository.addMessage(id, "user", question)
        container.chatRepository.addMessage(id, "model", formatEvaluation(result))
    }

    private fun snapshotJson(config: ScoreConfig): String {
        val sim = TargetScoreCalculator.simulate(config, states)
        return JSONObject()
            .put("target", config.target)
            .put("count", config.count)
            .put("weights", JSONArray(config.weights))
            .put("initialScore", config.initialScore)
            .put("wrongPenalty", config.wrongPenalty)
            .put("correct", sim.correct)
            .put("wrong", sim.wrong)
            .put("score", sim.score)
            .toString()
    }

    private fun formatEvaluation(result: EvalResult): String {
        val app = container.app
        val lines = result.items.map { item ->
            val status = when (item.isCorrect) {
                true -> app.getString(R.string.ts_eval_status_correct)
                false -> app.getString(R.string.ts_eval_status_wrong)
                null -> app.getString(R.string.ts_eval_status_unknown)
            }
            val tail = if (item.explanation.isBlank()) status else status + ". " + item.explanation.trim()
            app.getString(
                R.string.ts_eval_line,
                item.no,
                item.correctAnswer.ifBlank { "-" },
                item.userAnswer ?: app.getString(R.string.ts_eval_none),
                tail,
            )
        }
        return (lines + listOfNotNull(result.note)).joinToString("\n\n")
    }
}
