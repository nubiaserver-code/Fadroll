package com.fadrol.ai.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.fadrol.ai.R

/** Logo Fadrol: huruf F dan percikan di atas gradasi ungu kebiruan, sama dengan ikon aplikasi. */
@Composable
fun FadrolLogo(size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF7B72FF), Color(0xFF3F5BFF)))),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_fadrol_mark),
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .padding(size * 0.14f),
        )
    }
}

/**
 * Ikon perbesar/kecilkan yang digambar sendiri (tanpa library ikon tambahan).
 * isExpanded true menampilkan ikon "kecilkan"; false menampilkan ikon "perbesar".
 */
@Composable
fun ExpandIcon(isExpanded: Boolean, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(20.dp)) {
        val s = size.minDimension
        val arm = s * 0.26f
        val path = Path()

        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            path.moveTo(x + dx * arm, y)
            path.lineTo(x, y)
            path.lineTo(x, y + dy * arm)
        }

        if (isExpanded) {
            val c = s * 0.42f
            corner(c, c, -1f, -1f)
            corner(s - c, c, 1f, -1f)
            corner(c, s - c, -1f, 1f)
            corner(s - c, s - c, 1f, 1f)
        } else {
            val c = s * 0.16f
            corner(c, c, 1f, 1f)
            corner(s - c, c, -1f, 1f)
            corner(c, s - c, 1f, -1f)
            corner(s - c, s - c, -1f, -1f)
        }
        drawPath(path, tint, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
