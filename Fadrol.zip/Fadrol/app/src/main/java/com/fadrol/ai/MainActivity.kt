package com.fadrol.ai

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.fadrol.ai.ui.nav.FadrolNavHost
import com.fadrol.ai.ui.theme.FadrolTheme
import kotlinx.coroutines.runBlocking

/** Satu-satunya Activity utama. AppCompatActivity dipakai agar bahasa per-aplikasi bekerja di semua versi Android. */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = appContainer()
        // Baca sekali secara sinkron agar frame pertama sudah memakai tema pilihan pengguna.
        val initial = runBlocking { container.settings.snapshot() }
        setContent {
            val settings by container.settings.flow.collectAsState(initial = initial)
            FadrolTheme(settings.theme) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    FadrolNavHost(rememberNavController())
                }
            }
        }
    }
}
