package com.fadrol.ai.ui.components

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.fadrol.ai.R
import com.fadrol.ai.ocr.ImageUtils
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImagePickers(val gallery: () -> Unit, val camera: () -> Unit)

/**
 * Pemilih gambar dari galeri (Photo Picker) dan kamera. Foto kamera ditulis ke cache sementara
 * lalu langsung dihapus setelah dibaca; tidak ada gambar yang disimpan permanen.
 */
@Composable
fun rememberImagePickers(onBitmap: (Bitmap) -> Unit): ImagePickers {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentOnBitmap by rememberUpdatedState(onBitmap)
    var cameraFile by remember { mutableStateOf<File?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val bitmap = withContext(Dispatchers.IO) { ImageUtils.decodeUri(context, uri) }
                if (bitmap != null) {
                    currentOnBitmap(bitmap)
                } else {
                    Toast.makeText(context, R.string.picker_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val file = cameraFile
        cameraFile = null
        if (ok && file != null) {
            scope.launch {
                val bitmap = withContext(Dispatchers.IO) {
                    val decoded = ImageUtils.decodeFile(file)
                    file.delete()
                    decoded
                }
                if (bitmap != null) {
                    currentOnBitmap(bitmap)
                } else {
                    Toast.makeText(context, R.string.picker_failed, Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            file?.delete()
        }
    }

    return remember(galleryLauncher, cameraLauncher) {
        ImagePickers(
            gallery = {
                galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            camera = {
                val file = ImageUtils.newCameraFile(context)
                cameraFile = file
                cameraLauncher.launch(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
            },
        )
    }
}
