package com.fadrol.ai.targetscore

import org.json.JSONObject

data class EvalItem(
    val no: Int,
    val correctAnswer: String,
    val userAnswer: String?,
    /** Null bila AI tidak bisa memastikan atau pengguna tidak menulis jawaban. */
    val isCorrect: Boolean?,
    val explanation: String,
)

data class EvalResult(
    val items: List<EvalItem>,
    val note: String?,
)

/** Membaca JSON penilaian dari AI secara toleran (menyaring pagar kode atau teks di sekitar JSON). */
object EvalParser {

    fun parse(raw: String): EvalResult? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try {
            val root = JSONObject(raw.substring(start, end + 1))
            val array = root.optJSONArray("items") ?: return null
            val items = ArrayList<EvalItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                items.add(
                    EvalItem(
                        no = obj.optInt("no", i + 1),
                        correctAnswer = obj.optString("jawaban_benar", ""),
                        userAnswer = if (obj.isNull("jawaban_pengguna")) {
                            null
                        } else {
                            obj.optString("jawaban_pengguna", "").takeIf { it.isNotBlank() && it != "null" }
                        },
                        isCorrect = if (obj.isNull("benar")) null else obj.optBoolean("benar"),
                        explanation = obj.optString("penjelasan", ""),
                    ),
                )
            }
            EvalResult(items, root.optString("catatan", "").takeIf { it.isNotBlank() })
        } catch (e: Exception) {
            null
        }
    }
}
