package com.fadrol.ai.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import kotlin.math.max
import kotlin.math.roundToInt

/** Utilitas gambar: decode aman memori, putar, pangkas, deteksi layar hitam (aplikasi memblokir screenshot), dan kabur. */
object ImageUtils {

    const val MAX_SIDE = 2048

    fun decodeUri(context: Context, uri: Uri, maxSide: Int = MAX_SIDE): Bitmap? = try {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val rotation = resolver.openInputStream(uri)?.use { exifRotation(it) } ?: 0
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds, maxSide) }
        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        bmp?.let { downscale(rotate(it, rotation), maxSide) }
    } catch (e: Exception) {
        null
    }

    fun decodeFile(file: File, maxSide: Int = MAX_SIDE): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds, maxSide) }
        val bmp = BitmapFactory.decodeFile(file.path, opts)
        val rotation = file.inputStream().use { exifRotation(it) }
        bmp?.let { downscale(rotate(it, rotation), maxSide) }
    } catch (e: Exception) {
        null
    }

    /** File sementara untuk foto kamera, di cache/captures (lihat res/xml/file_paths.xml). */
    fun newCameraFile(context: Context): File {
        val dir = File(context.cacheDir, "captures").apply { mkdirs() }
        return File.createTempFile("cam_", ".jpg", dir)
    }

    private fun sampleSize(bounds: BitmapFactory.Options, maxSide: Int): Int {
        val longest = max(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (longest / (sample * 2) >= maxSide) sample *= 2
        return sample
    }

    private fun exifRotation(stream: InputStream): Int = try {
        when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    fun rotate(src: Bitmap, degrees: Int): Bitmap {
        if (degrees % 360 == 0) return src
        val m = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    fun downscale(src: Bitmap, maxSide: Int): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxSide) return src
        val scale = maxSide.toFloat() / longest
        val w = (src.width * scale).roundToInt().coerceAtLeast(1)
        val h = (src.height * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, w, h, true)
    }

    fun crop(src: Bitmap, left: Int, top: Int, right: Int, bottom: Int): Bitmap {
        val l = left.coerceIn(0, src.width - 1)
        val t = top.coerceIn(0, src.height - 1)
        val r = right.coerceIn(l + 1, src.width)
        val b = bottom.coerceIn(t + 1, src.height)
        return Bitmap.createBitmap(src, l, t, r - l, b - t)
    }

    fun toBase64Jpeg(bitmap: Bitmap, quality: Int = 85): String {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Aplikasi dengan FLAG_SECURE menghasilkan frame hitam pekat saat ditangkap.
     * Mengambil sampel piksel; true bila hampir semuanya hitam.
     */
    fun isMostlyBlank(bitmap: Bitmap): Boolean {
        val stepX = max(1, bitmap.width / 24)
        val stepY = max(1, bitmap.height / 24)
        var total = 0
        var dark = 0
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val c = bitmap.getPixel(x, y)
                total++
                if ((c shr 16 and 0xFF) + (c shr 8 and 0xFF) + (c and 0xFF) < 24) dark++
                x += stepX
            }
            y += stepY
        }
        return total > 0 && dark.toDouble() / total > 0.995
    }

    /** Variansi Laplacian pada versi kecil gambar. Makin kecil, makin buram. Ini heuristik, bukan jaminan. */
    fun sharpness(src: Bitmap): Double {
        val b = downscale(src, 480)
        val w = b.width
        val h = b.height
        if (w < 3 || h < 3) return 0.0
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val g = IntArray(w * h) { i ->
            val c = px[i]
            ((c shr 16 and 0xFF) * 299 + (c shr 8 and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
        }
        var sum = 0.0
        var sumSq = 0.0
        var n = 0
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val lap = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - w] - g[i + w]
                sum += lap
                sumSq += lap.toDouble() * lap
                n++
            }
        }
        val mean = sum / n
        return sumSq / n - mean * mean
    }
}
