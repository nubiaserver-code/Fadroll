package com.fadrol.ai.ai

import android.content.Context
import android.graphics.Bitmap
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException

/**
 * Gemini Developer API lewat Firebase AI Logic.
 * Membutuhkan app/google-services.json dan App Check (lihat docs/AI_SETUP.md).
 */
class FirebaseGeminiService(
    private val context: Context,
    private val modelName: String,
) : AiService {

    override suspend fun generate(
        system: String,
        history: List<ChatTurn>,
        prompt: String,
        bitmap: Bitmap?,
        json: Boolean,
    ): String {
        if (FirebaseApp.getApps(context).isEmpty()) throw AiException(AiErrorKind.FIREBASE_NOT_CONFIGURED)
        try {
            val model = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
                modelName = modelName,
                generationConfig = if (json) generationConfig { responseMimeType = "application/json" } else null,
                systemInstruction = content { text(system) },
            )
            val contents = ArrayList<Content>()
            for (turn in history) {
                contents.add(content(turn.role) { text(turn.text) })
            }
            contents.add(
                content("user") {
                    if (bitmap != null) image(bitmap)
                    text(prompt)
                },
            )
            val response = model.generateContent(*contents.toTypedArray())
            val out = response.text?.trim()
            if (out.isNullOrEmpty()) throw AiException(AiErrorKind.EMPTY)
            return out
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            throw e.toAiException()
        }
    }
}
