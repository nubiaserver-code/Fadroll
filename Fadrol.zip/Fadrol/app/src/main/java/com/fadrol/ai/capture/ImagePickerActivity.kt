package com.fadrol.ai.capture

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.fadrol.ai.R
import com.fadrol.ai.ocr.ImageUtils
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Activity transparan: memilih gambar dari galeri atau kamera untuk panel mengambang, lalu menutup diri. */
class ImagePickerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_CAMERA = "camera"
    }

    private var cameraFile: File? = null

    private val gallery = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) {
            finish()
        } else {
            deliver { ImageUtils.decodeUri(this, uri) }
        }
    }

    private val camera = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val file = cameraFile
        if (!ok || file == null) {
            file?.delete()
            finish()
        } else {
            deliver {
                val bitmap = ImageUtils.decodeFile(file)
                file.delete()
                bitmap
            }
        }
    }

    private fun deliver(load: () -> android.graphics.Bitmap?) {
        lifecycleScope.launch {
            val bitmap = withContext(Dispatchers.IO) { load() }
            if (bitmap != null) {
                ImageBus.emit(bitmap)
            } else {
                Toast.makeText(this@ImagePickerActivity, R.string.picker_failed, Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        if (intent.getBooleanExtra(EXTRA_CAMERA, false)) {
            val file = ImageUtils.newCameraFile(this)
            cameraFile = file
            camera.launch(FileProvider.getUriForFile(this, "$packageName.fileprovider", file))
        } else {
            gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }
}
