@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.fadrol.ai.targetscore

import androidx.annotation.StringRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.fadrol.ai.R
import com.fadrol.ai.ui.components.describeError
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Layar Target nilai: pengaturan, kebutuhan jawaban benar, simulasi benar/salah, dan mode latihan dengan AI.
 * Tidak memakai Dialog/Popup agar bisa tampil juga di dalam panel mengambang.
 */
@Composable
fun TargetScoreContent(
    state: TargetScoreState,
    onDiscuss: (String) -> Unit,
    onBackToChat: () -> Unit,
    modifier: Modifier = Modifier,
    onScanQuestions: (() -> Unit)? = null,
) {
    val parsed = state.parse()
    val config = (parsed as? ConfigResult.Ok)?.config
    val sim = config?.let { TargetScoreCalculator.simulate(it, state.states) }
    val req = config?.let { TargetScoreCalculator.requirement(it) }
    val status = config?.let { TargetScoreCalculator.status(it, state.states) }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        SettingsBlock(state, parsed)
        if (config != null && sim != null && req != null && status != null) {
            ScoreBlock(config, sim)
            RequirementBlock(config, req, status, sim)
            SimulationBlock(state, config)
        }
        if (state.practiceMode) PracticeBlock(state, onDiscuss, onScanQuestions)
        Text(
            text = stringResource(R.string.ts_disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        TextButton(onClick = onBackToChat) { Text(stringResource(R.string.ts_back_chat)) }
    }
}

@Composable
private fun SectionCard(@StringRes title: Int, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(title), style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun NumberField(
    value: String,
    onChange: (String) -> Unit,
    @StringRes label: Int,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    decimal: Boolean = false,
    @StringRes hint: Int? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        enabled = enabled,
        singleLine = true,
        label = { Text(stringResource(label)) },
        supportingText = if (hint != null) {
            { Text(stringResource(hint)) }
        } else {
            null
        },
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
        modifier = modifier,
    )
}

@Composable
private fun SettingsBlock(state: TargetScoreState, parsed: ConfigResult) {
    SectionCard(R.string.ts_settings) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NumberField(
                value = state.targetText,
                onChange = state::onTargetChange,
                label = R.string.ts_target_label,
                modifier = Modifier.weight(1f),
                decimal = true,
            )
            NumberField(
                value = state.countText,
                onChange = state::onCountChange,
                label = R.string.ts_count_label,
                modifier = Modifier.weight(1f),
                enabled = !state.customWeights,
            )
        }
        Slider(
            value = (state.targetText.replace(',', '.').toFloatOrNull() ?: 0f).coerceIn(0f, 100f),
            onValueChange = { state.targetText = it.roundToInt().toString() },
            valueRange = 0f..100f,
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(60, 70, 80, 85, 90, 100).forEach { preset ->
                FilterChip(
                    selected = state.targetText.replace(',', '.').toDoubleOrNull() == preset.toDouble(),
                    onClick = { state.targetText = preset.toString() },
                    label = { Text(preset.toString()) },
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.ts_custom_weights),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
            )
            Switch(checked = state.customWeights, onCheckedChange = state::onCustomToggle)
        }
        if (state.customWeights) {
            OutlinedTextField(
                value = state.weightsText,
                onValueChange = state::onWeightsChange,
                label = { Text(stringResource(R.string.ts_weights_label)) },
                supportingText = { Text(stringResource(R.string.ts_weights_hint)) },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NumberField(
                value = state.initialText,
                onChange = state::onInitialChange,
                label = R.string.ts_initial_label,
                modifier = Modifier.weight(1f),
                decimal = true,
            )
            NumberField(
                value = state.penaltyText,
                onChange = state::onPenaltyChange,
                label = R.string.ts_penalty_label,
                modifier = Modifier.weight(1f),
                decimal = true,
            )
        }
        Text(
            text = stringResource(R.string.ts_initial_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !state.practiceMode,
                onClick = { state.practiceMode = false },
                label = { Text(stringResource(R.string.ts_mode_sim)) },
            )
            FilterChip(
                selected = state.practiceMode,
                onClick = { state.practiceMode = true },
                label = { Text(stringResource(R.string.ts_mode_practice)) },
            )
        }
        if (parsed is ConfigResult.Invalid) {
            Text(
                text = stringResource(parsed.message),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }
    }
}

@Composable
private fun ScoreRing(score: Double, target: Double, centerLabel: String, subLabel: String) {
    val animated by animateFloatAsState(
        targetValue = (score / 100.0).toFloat().coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "score-ring",
    )
    val track = MaterialTheme.colorScheme.surfaceContainerHighest
    val fill = MaterialTheme.colorScheme.primary
    val tick = MaterialTheme.colorScheme.onSurface
    Box(Modifier.size(176.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val inset = stroke / 2f + 6.dp.toPx()
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            val topLeft = Offset(inset, inset)
            drawArc(track, 135f, 270f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (animated > 0f) {
                drawArc(fill, 135f, 270f * animated, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            // Penanda target pada cincin.
            val angle = Math.toRadians(135.0 + 270.0 * (target / 100.0))
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = arcSize.width / 2f
            val inner = radius - stroke / 2f - 3.dp.toPx()
            val outer = radius + stroke / 2f + 3.dp.toPx()
            drawLine(
                color = tick,
                start = Offset(cx + (inner * cos(angle)).toFloat(), cy + (inner * sin(angle)).toFloat()),
                end = Offset(cx + (outer * cos(angle)).toFloat(), cy + (outer * sin(angle)).toFloat()),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerLabel, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            Text(
                text = subLabel,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun Stat(value: Int, @StringRes label: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), style = MaterialTheme.typography.titleLarge)
        Text(
            text = stringResource(label),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ScoreBlock(config: ScoreConfig, sim: SimulationResult) {
    val percent = min(sim.targetProgress * 100.0, 999.0)
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.ts_score),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        ScoreRing(
            score = sim.score,
            target = config.target,
            centerLabel = TargetScoreCalculator.formatNumber(sim.score),
            subLabel = stringResource(R.string.ts_target_short, TargetScoreCalculator.formatNumber(config.target)),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat(sim.correct, R.string.ts_stat_correct)
            Stat(sim.wrong, R.string.ts_stat_wrong)
            Stat(sim.unanswered, R.string.ts_stat_blank)
        }
        LinearProgressIndicator(
            progress = { sim.targetProgress.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
        )
        Text(
            text = stringResource(R.string.ts_progress, TargetScoreCalculator.formatNumber(percent)),
            style = MaterialTheme.typography.bodyMedium,
        )
        val gapText = when {
            kotlin.math.abs(sim.gap) < 0.005 -> stringResource(R.string.ts_gap_equal)
            sim.gap > 0 -> stringResource(R.string.ts_gap_above, TargetScoreCalculator.formatNumber(sim.gap))
            else -> stringResource(R.string.ts_gap_below, TargetScoreCalculator.formatNumber(-sim.gap))
        }
        Text(gapText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun RequirementBlock(config: ScoreConfig, req: Requirement, status: StateStatus, sim: SimulationResult) {
    val n = config.count
    val lines = ArrayList<String>()
    if (req.alreadyMet) {
        lines.add(stringResource(R.string.ts_req_met))
    } else if (req.equalWeights && !req.hasPenalty) {
        lines.add(stringResource(R.string.ts_req_equal, req.minCorrect, n, n - req.minCorrect))
    } else if (req.equalWeights) {
        lines.add(stringResource(R.string.ts_req_equal_blank, req.minCorrect))
        lines.add(stringResource(R.string.ts_req_equal_wrong, req.minCorrectIfRestWrong))
    } else {
        lines.add(stringResource(R.string.ts_req_custom_best, req.minCorrect))
        lines.add(stringResource(R.string.ts_req_custom_safe, req.safeCorrect))
        if (req.hasPenalty) {
            lines.add(stringResource(R.string.ts_req_custom_best_wrong, req.minCorrectIfRestWrong, req.safeCorrectIfRestWrong))
        }
    }
    SectionCard(R.string.ts_need_title) {
        lines.forEach { Text(it, style = MaterialTheme.typography.bodyLarge) }
        val touched = sim.correct + sim.wrong > 0
        if (!status.reachable) {
            Text(
                text = stringResource(
                    R.string.ts_unreachable,
                    TargetScoreCalculator.formatNumber(status.bestPossibleScore),
                    TargetScoreCalculator.formatNumber(config.target),
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
            )
        } else if (touched) {
            val more = status.moreCorrectNeeded
            if (more == 0) {
                Text(stringResource(R.string.ts_reached_now), style = MaterialTheme.typography.bodyMedium)
            } else if (more != null) {
                Text(
                    text = stringResource(R.string.ts_more_needed, more, status.unansweredLeft),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun StepperRow(@StringRes label: Int, value: Int, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        FilledTonalIconButton(onClick = onMinus) { Text("\u2212", style = MaterialTheme.typography.titleLarge) }
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .heightIn(min = 24.dp),
        )
        FilledTonalIconButton(onClick = onPlus) { Text("+", style = MaterialTheme.typography.titleLarge) }
    }
}

@Composable
private fun QuestionChip(number: Int, answer: AnswerState, weight: String?, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val container = when (answer) {
        AnswerState.UNANSWERED -> colors.surfaceContainerHigh
        AnswerState.CORRECT -> colors.primary
        AnswerState.WRONG -> colors.errorContainer
    }
    val content = when (answer) {
        AnswerState.UNANSWERED -> colors.onSurfaceVariant
        AnswerState.CORRECT -> colors.onPrimary
        AnswerState.WRONG -> colors.onErrorContainer
    }
    val mark = when (answer) {
        AnswerState.UNANSWERED -> "\u00B7"
        AnswerState.CORRECT -> "\u2713"
        AnswerState.WRONG -> "\u2717"
    }
    Surface(
        onClick = onClick,
        color = container,
        contentColor = content,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.size(width = 46.dp, height = 50.dp),
    ) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(number.toString(), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(
                text = if (weight != null) "$mark \u00D7$weight" else mark,
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

@Composable
private fun SimulationBlock(state: TargetScoreState, config: ScoreConfig) {
    SectionCard(R.string.ts_sim_title) {
        Text(
            text = stringResource(R.string.ts_sim_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (config.equalWeights) {
            StepperRow(
                label = R.string.ts_correct_count,
                value = state.correctCount,
                onMinus = { state.setCounts(state.correctCount - 1, state.wrongCount) },
                onPlus = { state.setCounts(state.correctCount + 1, state.wrongCount) },
            )
            StepperRow(
                label = R.string.ts_wrong_count,
                value = state.wrongCount,
                onMinus = { state.setCounts(state.correctCount, state.wrongCount - 1) },
                onPlus = { state.setCounts(state.correctCount, state.wrongCount + 1) },
            )
        }
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            state.states.forEachIndexed { index, answer ->
                val weight = if (config.equalWeights) null else TargetScoreCalculator.formatNumber(config.weights[index])
                QuestionChip(index + 1, answer, weight) { state.cycle(index) }
            }
        }
        TextButton(onClick = state::resetAnswers) { Text(stringResource(R.string.ts_reset)) }
    }
}

@Composable
private fun PracticeBlock(state: TargetScoreState, onDiscuss: (String) -> Unit, onScan: (() -> Unit)?) {
    val context = LocalContext.current
    val lastOcr by state.lastOcrText.collectAsState()
    SectionCard(R.string.ts_practice_title) {
        Text(
            text = stringResource(R.string.ts_practice_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = state.practiceText,
            onValueChange = { state.practiceText = it },
            label = { Text(stringResource(R.string.ts_practice_label)) },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 140.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (lastOcr != null) {
                TextButton(onClick = state::useLastOcr) { Text(stringResource(R.string.ts_use_ocr)) }
            }
            if (onScan != null) {
                TextButton(onClick = onScan) { Text(stringResource(R.string.ts_scan)) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { onDiscuss(state.discussPrompt()) },
                enabled = state.practiceText.isNotBlank(),
                modifier = Modifier.weight(1f),
            ) { Text(stringResource(R.string.ts_discuss)) }
            Button(
                onClick = state::evaluate,
                enabled = state.practiceText.isNotBlank() && !state.evaluating,
                modifier = Modifier.weight(1f),
            ) { Text(stringResource(if (state.evaluating) R.string.ts_analyzing else R.string.ts_analyze)) }
        }
        if (state.evaluating) LinearProgressIndicator(Modifier.fillMaxWidth())
        state.evalError?.let {
            Text(describeError(context, it), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        if (state.evalParseFailed) {
            Text(
                text = stringResource(R.string.ts_eval_parse_failed),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }
        state.evaluation?.let { result -> EvaluationList(result) }
    }
}

@Composable
private fun EvaluationList(result: EvalResult) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.ts_eval_title), style = MaterialTheme.typography.titleSmall)
        result.items.forEach { item ->
            val status = when (item.isCorrect) {
                true -> stringResource(R.string.ts_eval_status_correct)
                false -> stringResource(R.string.ts_eval_status_wrong)
                null -> stringResource(R.string.ts_eval_status_unknown)
            }
            val tail = if (item.explanation.isBlank()) status else status + ". " + item.explanation.trim()
            Surface(
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = stringResource(
                        R.string.ts_eval_line,
                        item.no,
                        item.correctAnswer.ifBlank { "-" },
                        item.userAnswer ?: stringResource(R.string.ts_eval_none),
                        tail,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(10.dp),
                )
            }
        }
        result.note?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
