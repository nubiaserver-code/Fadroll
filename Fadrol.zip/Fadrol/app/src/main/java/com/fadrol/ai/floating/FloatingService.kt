package com.fadrol.ai.floating

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.ComposeView
import androidx.core.animation.doOnEnd
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.fadrol.ai.AppContainer
import com.fadrol.ai.MainActivity
import com.fadrol.ai.R
import com.fadrol.ai.appContainer
import com.fadrol.ai.capture.CaptureCoordinator
import com.fadrol.ai.capture.CaptureEvent
import com.fadrol.ai.capture.ImageBus
import com.fadrol.ai.capture.ImagePickerActivity
import com.fadrol.ai.capture.ScreenCaptureActivity
import com.fadrol.ai.settings.AppSettings
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Akar jendela panel: meneruskan tombol Kembali ke service agar panel bisa ditutup. */
private class PanelRoot(context: Context, private val onBack: () -> Unit) : FrameLayout(context) {
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}

/**
 * Ikon mengambang + panel AI di atas aplikasi lain, memakai WindowManager dan izin SYSTEM_ALERT_WINDOW.
 * Berjalan sebagai foreground service (specialUse) selama pengguna menyalakannya dan dapat dihentikan kapan saja
 * dari aplikasi, notifikasi, atau menu panel.
 */
class FloatingService : Service() {

    companion object {
        const val ACTION_START = "com.fadrol.ai.floating.START"
        const val ACTION_STOP = "com.fadrol.ai.floating.STOP"
        const val ACTION_SHOW_ICON = "com.fadrol.ai.floating.SHOW_ICON"
        const val ACTION_HIDE_ICON = "com.fadrol.ai.floating.HIDE_ICON"
        const val ACTION_OPEN_PANEL = "com.fadrol.ai.floating.OPEN_PANEL"
        const val ACTION_CAPTURE = "com.fadrol.ai.floating.CAPTURE"
        const val EXTRA_DELAY_MS = "delay_ms"
        const val EXTRA_GO_HOME = "go_home"

        private const val CHANNEL_ID = "fadrol_floating"
        private const val NOTIF_ID = 1001

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(context: Context, action: String = ACTION_START, delayMs: Long = 0L, goHome: Boolean = false) {
            val intent = Intent(context, FloatingService::class.java)
                .setAction(action)
                .putExtra(EXTRA_DELAY_MS, delayMs)
                .putExtra(EXTRA_GO_HOME, goHome)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var owner: OverlayLifecycleOwner
    private lateinit var container: AppContainer
    private lateinit var ui: PanelUi
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var settings = AppSettings()
    private var iconView: FrameLayout? = null
    private var iconParams: WindowManager.LayoutParams? = null
    private var panelView: PanelRoot? = null
    private var iconHiddenByUser = false
    private var overlaysSuspended = false
    private var slop = 0
    private var lastPersisted: Pair<Boolean, Int>? = null

    private val actions by lazy {
        PanelActions(
            onClose = { hidePanel() },
            onPickGallery = { launchPicker(camera = false) },
            onPickCamera = { launchPicker(camera = true) },
            onReadScreen = { requestCapture(delayMs = 900L, goHome = false) },
            onHideIcon = {
                hidePanel()
                setIconHiddenByUser(true)
            },
            onStopService = { stopSelf() },
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        container = appContainer()
        slop = ViewConfiguration.get(this).scaledTouchSlop
        owner = OverlayLifecycleOwner().also {
            it.create()
            it.resume()
        }
        ui = PanelUi(container, scope)
        createChannel()
        startAsForeground()
        _running.value = true

        scope.launch {
            settings = container.settings.snapshot()
            createIcon()
        }
        scope.launch {
            container.settings.flow.collect { latest ->
                val sizeChanged = settings.iconSizeDp != latest.iconSizeDp
                val positionChanged = settings.iconLeft != latest.iconLeft || settings.iconY != latest.iconY
                // Perubahan posisi yang kita tulis sendiri setelah drag tidak perlu diterapkan ulang.
                val ours = lastPersisted == (latest.iconLeft to latest.iconY)
                settings = latest
                if (iconView != null) {
                    if (sizeChanged) {
                        removeIcon()
                        createIcon()
                    } else if (positionChanged && !ours) {
                        repositionIcon()
                    }
                }
            }
        }
        scope.launch { snapshotFlow { ui.size }.collect { applyPanelLayout() } }
        scope.launch { CaptureCoordinator.events.collect { onCaptureEvent(it) } }
        scope.launch {
            ImageBus.images.collect { bitmap ->
                ui.chat.attachImage(bitmap)
                ui.view = PanelView.CHAT
                showPanel()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_HIDE_ICON -> setIconHiddenByUser(true)
            ACTION_SHOW_ICON -> setIconHiddenByUser(false)
            ACTION_OPEN_PANEL -> showPanel()
            ACTION_CAPTURE -> requestCapture(
                delayMs = (intent?.getLongExtra(EXTRA_DELAY_MS, 900L) ?: 900L).coerceAtLeast(900L),
                goHome = intent?.getBooleanExtra(EXTRA_GO_HOME, false) ?: false,
            )
        }
        // Tidak dihidupkan ulang otomatis: izin overlay bisa saja dicabut saat proses mati.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        _running.value = false
        hidePanel()
        removeIcon()
        ui.chat.close()
        scope.cancel()
        owner.destroy()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val view = iconView
        val lp = iconParams
        if (view != null && lp != null) {
            val (sw, sh) = screenSize()
            lp.x = if (settings.iconLeft) 0 else sw - lp.width
            lp.y = lp.y.coerceIn(minY(), maxY(lp.height, sh))
            safeUpdate(view, lp)
        }
        applyPanelLayout()
    }

    // ---------------------------------------------------------------- ikon

    private fun createIcon() {
        if (iconView != null || iconHiddenByUser) return
        val size = dp(settings.iconSizeDp)
        val (sw, sh) = screenSize()
        val root = FrameLayout(this)
        root.background = ContextCompat.getDrawable(this, R.drawable.bg_floating_icon)
        val mark = ImageView(this)
        mark.setImageResource(R.drawable.ic_fadrol_mark)
        mark.scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = size / 6
        mark.setPadding(pad, pad, pad, pad)
        root.addView(mark, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.contentDescription = getString(R.string.app_name)
        root.alpha = 0f
        root.scaleX = 0.4f
        root.scaleY = 0.4f

        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (settings.iconLeft) 0 else sw - size
        lp.y = if (settings.iconY >= 0) settings.iconY.coerceIn(minY(), maxY(size, sh)) else (sh * 0.35f).toInt()

        root.setOnTouchListener(DragTouchListener(lp))
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            // Izin overlay dicabut atau tidak diberikan: hentikan layanan dengan rapi.
            Toast.makeText(this, R.string.overlay_guide_title, Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        iconView = root
        iconParams = lp
        root.visibility = if (overlaysSuspended) View.INVISIBLE else View.VISIBLE
        root.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(240)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    private fun removeIcon() {
        iconView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // sudah dilepas
            }
        }
        iconView = null
        iconParams = null
    }

    private fun setIconHiddenByUser(hidden: Boolean) {
        iconHiddenByUser = hidden
        if (hidden) removeIcon() else createIcon()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun updateOverlayVisibility() {
        val visibility = if (overlaysSuspended) View.INVISIBLE else View.VISIBLE
        iconView?.visibility = visibility
        panelView?.visibility = visibility
    }

    private inner class DragTouchListener(private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var downX = 0f
        private var downY = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    downX = e.rawX
                    downY = e.rawY
                    moved = false
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        val (sw, sh) = screenSize()
                        lp.x = (startX + dx).toInt().coerceIn(0, sw - lp.width)
                        lp.y = (startY + dy).toInt().coerceIn(minY(), maxY(lp.height, sh))
                        safeUpdate(v, lp)
                    }
                    return true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (moved) {
                            snapToEdge()
                        } else {
                            v.performClick()
                            togglePanel()
                        }
                    }
                    return true
                }
            }
            return false
        }
    }

    private fun snapToEdge() {
        val view = iconView ?: return
        val lp = iconParams ?: return
        val (sw, _) = screenSize()
        val toLeft = lp.x + lp.width / 2 < sw / 2
        val target = if (toLeft) 0 else sw - lp.width
        val from = lp.x
        if (!settings.snapToEdge || from == target) {
            persistPosition(toLeft, lp.y)
            return
        }
        ValueAnimator.ofInt(from, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                safeUpdate(view, lp)
            }
            doOnEnd { persistPosition(toLeft, lp.y) }
            start()
        }
    }

    private fun persistPosition(left: Boolean, y: Int) {
        lastPersisted = left to y
        scope.launch { container.settings.setIconPosition(left, y) }
    }

    /** Menerapkan pilihan sisi/reset posisi dari Pengaturan pada ikon yang sedang tampil. */
    private fun repositionIcon() {
        val view = iconView ?: return
        val lp = iconParams ?: return
        val (sw, sh) = screenSize()
        lp.x = if (settings.iconLeft) 0 else sw - lp.width
        lp.y = if (settings.iconY >= 0) settings.iconY.coerceIn(minY(), maxY(lp.height, sh)) else (sh * 0.35f).toInt()
        safeUpdate(view, lp)
    }

    // ---------------------------------------------------------------- panel

    private fun togglePanel() {
        if (panelView != null) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panelView != null) {
            if (ui.size == PanelSize.MINI) ui.size = PanelSize.NORMAL
            applyPanelLayout()
            return
        }
        val root = PanelRoot(this) { handleBack() }
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        val compose = ComposeView(this)
        compose.setViewTreeLifecycleOwner(owner)
        compose.setViewTreeViewModelStoreOwner(owner)
        compose.setViewTreeSavedStateRegistryOwner(owner)
        compose.setContent { FloatingPanelHost(ui, actions, settings) }
        root.addView(compose, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        try {
            wm.addView(root, buildPanelParams())
        } catch (e: Exception) {
            return
        }
        panelView = root
        updateOverlayVisibility()
    }

    private fun hidePanel() {
        val view = panelView ?: return
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // sudah dilepas
        }
        panelView = null
        ui.menuOpen = false
    }

    private fun handleBack() {
        if (ui.view != PanelView.CHAT) ui.view = PanelView.CHAT else hidePanel()
    }

    private fun applyPanelLayout() {
        val view = panelView ?: return
        safeUpdate(view, buildPanelParams())
    }

    /**
     * Panel menempel di bagian atas layar dan tidak memakai seluruh tinggi layar, sehingga keyboard di bagian bawah
     * tidak menutupinya. Sentuhan di luar panel diteruskan ke aplikasi di bawahnya (FLAG_NOT_TOUCH_MODAL).
     */
    private fun buildPanelParams(): WindowManager.LayoutParams {
        val (sw, sh) = screenSize()
        val margin = dp(8)
        val width = minOf(sw - 2 * margin, dp(480))
        val height = when (ui.size) {
            PanelSize.MINI -> WindowManager.LayoutParams.WRAP_CONTENT
            PanelSize.NORMAL -> (sh * 0.52f).toInt()
            PanelSize.EXPANDED -> (sh * 0.88f).toInt() - statusBarHeight()
        }
        val lp = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = statusBarHeight() + dp(6)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        return lp
    }

    // ---------------------------------------------------------------- galeri, kamera, tangkap layar

    private fun launchPicker(camera: Boolean) {
        val intent = Intent(this, ImagePickerActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(ImagePickerActivity.EXTRA_CAMERA, camera)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.picker_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestCapture(delayMs: Long, goHome: Boolean) {
        val intent = Intent(this, ScreenCaptureActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            .putExtra(ScreenCaptureActivity.EXTRA_DELAY_MS, delayMs)
            .putExtra(ScreenCaptureActivity.EXTRA_GO_HOME, goHome)
        try {
            // Dimulai selagi overlay masih tampil, lalu panel disembunyikan agar tidak ikut tertangkap.
            startActivity(intent)
            hidePanel()
        } catch (e: Exception) {
            ui.notice = R.string.capture_failed
        }
    }

    private fun onCaptureEvent(event: CaptureEvent) {
        when (event) {
            CaptureEvent.Capturing -> {
                overlaysSuspended = true
                updateOverlayVisibility()
            }

            is CaptureEvent.Captured -> {
                overlaysSuspended = false
                updateOverlayVisibility()
                ui.scan.start(event.bitmap, event.suspectedBlocked)
                ui.view = PanelView.SCAN
                ui.size = PanelSize.EXPANDED
                showPanel()
            }

            is CaptureEvent.Failed -> {
                overlaysSuspended = false
                updateOverlayVisibility()
                ui.notice = R.string.capture_failed
                ui.view = PanelView.CHAT
                showPanel()
            }

            CaptureEvent.Cancelled -> {
                overlaysSuspended = false
                updateOverlayVisibility()
            }
        }
    }

    // ---------------------------------------------------------------- notifikasi

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW),
        )
    }

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        fun serviceIntent(action: String, requestCode: Int) = PendingIntent.getService(
            this,
            requestCode,
            Intent(this, FloatingService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val toggleLabel = if (iconHiddenByUser) R.string.notif_show_icon else R.string.notif_hide_icon
        val toggleAction = if (iconHiddenByUser) ACTION_SHOW_ICON else ACTION_HIDE_ICON
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_fadrol_mark)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, getString(toggleLabel), serviceIntent(toggleAction, 1))
            .addAction(0, getString(R.string.notif_stop), serviceIntent(ACTION_STOP, 2))
            .build()
    }

    // ---------------------------------------------------------------- util

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun navBarHeight(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun minY(): Int = statusBarHeight()

    private fun maxY(iconSize: Int, screenHeight: Int): Int =
        (screenHeight - iconSize - navBarHeight() - dp(16)).coerceAtLeast(minY())

    private fun safeUpdate(view: View, lp: WindowManager.LayoutParams) {
        try {
            wm.updateViewLayout(view, lp)
        } catch (e: IllegalArgumentException) {
            // view sudah dilepas
        }
    }
}
