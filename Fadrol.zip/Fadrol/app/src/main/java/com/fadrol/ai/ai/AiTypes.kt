package com.fadrol.ai.ai

import java.io.IOException

/** Satu giliran percakapan. role: "user" atau "model". */
data class ChatTurn(val role: String, val text: String)

enum class AiSource { FIREBASE, OWN_KEY }

enum class AiErrorKind { FIREBASE_NOT_CONFIGURED, NO_API_KEY, NETWORK, API, EMPTY }

/** Galat AI dengan jenis yang jelas; UI menerjemahkannya ke pesan yang bisa dipahami pengguna. */
class AiException(
    val kind: AiErrorKind,
    val detail: String? = null,
    cause: Throwable? = null,
) : Exception(detail, cause)

data class AiStatus(
    val source: AiSource,
    val configured: Boolean,
    val problem: AiErrorKind?,
)

internal fun Throwable.toAiException(): AiException {
    if (this is AiException) return this
    val chain = generateSequence(this) { it.cause }.take(8).toList()
    return if (chain.any { it is IOException }) {
        AiException(AiErrorKind.NETWORK, message, this)
    } else {
        AiException(AiErrorKind.API, message ?: javaClass.simpleName, this)
    }
}
