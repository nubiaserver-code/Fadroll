@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.components

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.fadrol.ai.R
import com.fadrol.ai.floating.FloatingService

/** Panduan izin overlay: menjelaskan alasannya, lalu membuka layar izin sistem. */
@Composable
fun OverlayGuideDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.overlay_guide_title)) },
        text = { Text(stringResource(R.string.overlay_guide_body)) },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")),
                )
            }) { Text(stringResource(R.string.open_settings)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

/** Saklar untuk menyalakan/mematikan layanan ikon mengambang, lengkap dengan alur izin. */
@Composable
fun FloatingSwitchCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val running by FloatingService.running.collectAsState()
    var showGuide by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Notifikasi boleh ditolak; layanan tetap berjalan dan bisa dihentikan dari aplikasi.
        FloatingService.start(context)
    }

    fun enable() {
        if (!Settings.canDrawOverlays(context)) {
            showGuide = true
            return
        }
        val needsNotificationPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotificationPermission) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            FloatingService.start(context)
        }
    }

    if (showGuide) OverlayGuideDialog { showGuide = false }

    Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.fillMaxWidth(),
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.floating_title), style = MaterialTheme.typography.titleMedium)
                Text(
                    text = stringResource(if (running) R.string.floating_on else R.string.floating_off),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = running,
                onCheckedChange = { wantOn -> if (wantOn) enable() else FloatingService.stop(context) },
            )
        }
    }
}

/**
 * Aksi "Baca soal di layar" untuk layar utama dan AI Chat: cek izin overlay, jelaskan alurnya,
 * lalu minta layanan mengambang memulai permintaan persetujuan tangkap layar.
 */
@Composable
fun rememberScreenReadAction(): () -> Unit {
    val context = LocalContext.current
    var showGuide by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }

    if (showGuide) OverlayGuideDialog { showGuide = false }
    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text(stringResource(R.string.capture_info_title)) },
            text = { Text(stringResource(R.string.capture_info_body)) },
            confirmButton = {
                TextButton(onClick = {
                    showInfo = false
                    FloatingService.start(
                        context,
                        action = FloatingService.ACTION_CAPTURE,
                        delayMs = 6_000L,
                        goHome = true,
                    )
                }) { Text(stringResource(R.string.capture_info_continue)) }
            },
            dismissButton = { TextButton(onClick = { showInfo = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
    return remember {
        {
            if (Settings.canDrawOverlays(context)) {
                showInfo = true
            } else {
                showGuide = true
            }
        }
    }
}
