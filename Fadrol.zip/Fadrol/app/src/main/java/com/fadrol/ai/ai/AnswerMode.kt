package com.fadrol.ai.ai

/** Tiga mode jawaban: singkat, penjelasan lengkap, dan mode belajar bertahap. */
enum class AnswerMode(val key: String) {
    SHORT("short"),
    FULL("full"),
    LEARN("learn");

    companion object {
        fun from(key: String?): AnswerMode = entries.firstOrNull { it.key == key } ?: FULL
    }
}
