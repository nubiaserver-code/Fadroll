package com.fadrol.ai.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.fadrol.ai.ui.screens.AboutScreen
import com.fadrol.ai.ui.screens.ChatScreen
import com.fadrol.ai.ui.screens.HistoryScreen
import com.fadrol.ai.ui.screens.HomeScreen
import com.fadrol.ai.ui.screens.ScanScreen
import com.fadrol.ai.ui.screens.SettingsScreen
import com.fadrol.ai.ui.screens.SplashScreen
import com.fadrol.ai.ui.screens.TargetScoreScreen

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CHAT = "chat"
    const val CHAT_PATTERN = "chat?cid={cid}"
    const val SCAN = "scan"
    const val TARGET = "target"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val ABOUT = "about"

    fun chat(conversationId: Long? = null): String = if (conversationId == null) CHAT else "chat?cid=$conversationId"
}

@Composable
fun FadrolNavHost(nav: NavHostController) {
    // Membuka AI Chat selalu menggantikan instance lama agar titipan dari Scan/Target nilai diproses di layar baru.
    fun openChat(conversationId: Long? = null) {
        nav.navigate(Routes.chat(conversationId)) {
            popUpTo(Routes.CHAT_PATTERN) { inclusive = true }
        }
    }

    NavHost(navController = nav, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen {
                nav.navigate(Routes.HOME) { popUpTo(Routes.SPLASH) { inclusive = true } }
            }
        }
        composable(Routes.HOME) {
            HomeScreen(
                onOpenChat = { openChat() },
                onOpenTarget = { nav.navigate(Routes.TARGET) },
                onOpenScan = { nav.navigate(Routes.SCAN) },
                onOpenHistory = { nav.navigate(Routes.HISTORY) },
                onOpenConversation = { id -> openChat(id) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) },
            )
        }
        composable(
            route = Routes.CHAT_PATTERN,
            arguments = listOf(navArgument("cid") { type = NavType.LongType; defaultValue = -1L }),
        ) { entry ->
            ChatScreen(
                conversationId = entry.arguments?.getLong("cid") ?: -1L,
                onBack = { nav.popBackStack() },
                onOpenTarget = { nav.navigate(Routes.TARGET) },
                onOpenHistory = { nav.navigate(Routes.HISTORY) },
            )
        }
        composable(Routes.SCAN) {
            ScanScreen(
                onBack = { nav.popBackStack() },
                onSentToChat = { openChat() },
                onUseForTarget = {
                    if (!nav.popBackStack(Routes.TARGET, false)) nav.navigate(Routes.TARGET)
                },
            )
        }
        composable(Routes.TARGET) {
            TargetScoreScreen(
                onBack = { nav.popBackStack() },
                onOpenChat = { openChat() },
                onScan = { nav.navigate(Routes.SCAN) },
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                onBack = { nav.popBackStack() },
                onOpen = { id -> openChat(id) },
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { nav.popBackStack() },
                onOpenAbout = { nav.navigate(Routes.ABOUT) },
            )
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = { nav.popBackStack() })
        }
    }
}
