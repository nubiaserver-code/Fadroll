package com.fadrol.ai.capture

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.fadrol.ai.R

/**
 * Activity transparan yang hanya menampilkan dialog persetujuan tangkap layar milik sistem Android
 * (MediaProjection). Tanpa persetujuan pengguna, tidak ada screenshot yang diambil.
 */
class ScreenCaptureActivity : ComponentActivity() {

    companion object {
        const val EXTRA_DELAY_MS = "delay_ms"
        const val EXTRA_GO_HOME = "go_home"
    }

    private var delayMs = 900L
    private var goHome = false

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                .putExtra(ScreenCaptureService.EXTRA_DELAY_MS, delayMs)
            ContextCompat.startForegroundService(this, service)
            if (goHome) {
                Toast.makeText(this, R.string.capture_countdown_toast, Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_HOME)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        } else {
            CaptureCoordinator.emit(CaptureEvent.Cancelled)
            Toast.makeText(this, R.string.capture_denied, Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        delayMs = intent.getLongExtra(EXTRA_DELAY_MS, 900L)
        goHome = intent.getBooleanExtra(EXTRA_GO_HOME, false)
        if (savedInstanceState == null) {
            val manager = getSystemService(MediaProjectionManager::class.java)
            launcher.launch(manager.createScreenCaptureIntent())
        }
    }
}
