@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.fadrol.ai.ui.screens

import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.fadrol.ai.AppContainer
import com.fadrol.ai.BuildConfig
import com.fadrol.ai.R
import com.fadrol.ai.ai.AiSource
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.ai.AppCheckInstaller
import com.fadrol.ai.appContainer
import com.fadrol.ai.settings.AppSettings
import com.fadrol.ai.settings.ThemeMode
import com.fadrol.ai.settings.toNightMode
import com.fadrol.ai.ui.components.FloatingSwitchCard
import com.fadrol.ai.ui.components.copyToClipboard
import com.fadrol.ai.ui.components.describeError
import com.fadrol.ai.ui.components.labelRes
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenAbout: () -> Unit) {
    val context = LocalContext.current
    val container = remember { context.appContainer() }
    val settings by container.settings.flow.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    var confirmClear by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            FloatingSection(settings, container, scope)
            DisplaySection(settings, container, scope)
            AiSection(settings, container, scope)
            HistorySection(settings, container, scope) { confirmClear = true }
            SectionTitle(R.string.settings_privacy)
            Text(
                text = stringResource(R.string.settings_privacy_body),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            TextButton(onClick = onOpenAbout) { Text(stringResource(R.string.settings_about)) }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(stringResource(R.string.history_delete_all_title)) },
            text = { Text(stringResource(R.string.history_delete_all_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch { container.chatRepository.deleteAll() }
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun SectionTitle(@StringRes title: Int) {
    Text(
        text = stringResource(title),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 10.dp),
    )
}

@Composable
private fun SwitchRow(@StringRes label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T> LabeledChips(@StringRes label: Int, options: List<Pair<T, Int>>, selected: T, onSelect: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, text) ->
                FilterChip(
                    selected = value == selected,
                    onClick = { onSelect(value) },
                    label = { Text(stringResource(text)) },
                )
            }
        }
    }
}

@Composable
private fun FloatingSection(settings: AppSettings, container: AppContainer, scope: CoroutineScope) {
    SectionTitle(R.string.settings_floating)
    FloatingSwitchCard()
    var sizeValue by remember(settings.iconSizeDp) { mutableFloatStateOf(settings.iconSizeDp.toFloat()) }
    Text(
        text = stringResource(R.string.settings_icon_size, sizeValue.roundToInt()),
        style = MaterialTheme.typography.bodyLarge,
    )
    Slider(
        value = sizeValue,
        onValueChange = { sizeValue = it },
        onValueChangeFinished = { scope.launch { container.settings.setIconSize(sizeValue.roundToInt()) } },
        valueRange = 40f..88f,
    )
    SwitchRow(R.string.settings_snap, settings.snapToEdge) { scope.launch { container.settings.setSnapToEdge(it) } }
    LabeledChips(
        label = R.string.settings_side,
        options = listOf(true to R.string.settings_left, false to R.string.settings_right),
        selected = settings.iconLeft,
    ) { scope.launch { container.settings.setIconSide(it) } }
    TextButton(onClick = { scope.launch { container.settings.resetIconPosition() } }) {
        Text(stringResource(R.string.settings_reset_pos))
    }
}

@Composable
private fun DisplaySection(settings: AppSettings, container: AppContainer, scope: CoroutineScope) {
    SectionTitle(R.string.settings_display)
    LabeledChips(
        label = R.string.settings_theme,
        options = listOf(
            ThemeMode.SYSTEM to R.string.theme_system,
            ThemeMode.LIGHT to R.string.theme_light,
            ThemeMode.DARK to R.string.theme_dark,
        ),
        selected = settings.theme,
    ) { mode ->
        scope.launch {
            container.settings.setTheme(mode)
            AppCompatDelegate.setDefaultNightMode(mode.toNightMode())
        }
    }
    LabeledChips(
        label = R.string.settings_language,
        options = listOf(
            "system" to R.string.lang_system,
            "id" to R.string.lang_id,
            "en" to R.string.lang_en,
        ),
        selected = settings.language,
    ) { code ->
        scope.launch {
            container.settings.setLanguage(code)
            AppCompatDelegate.setApplicationLocales(
                if (code == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(code),
            )
        }
    }
}

@Composable
private fun AiSection(settings: AppSettings, container: AppContainer, scope: CoroutineScope) {
    val context = LocalContext.current
    SectionTitle(R.string.settings_ai)
    LabeledChips(
        label = R.string.settings_ai_source,
        options = listOf(
            AiSource.FIREBASE to R.string.ai_source_firebase,
            AiSource.OWN_KEY to R.string.ai_source_key,
        ),
        selected = settings.aiSource,
    ) { source ->
        scope.launch {
            container.settings.setAiSource(source)
            container.aiVerified.value = false
        }
    }

    var model by remember(settings.modelName) { mutableStateOf(settings.modelName) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = model,
            onValueChange = { model = it },
            label = { Text(stringResource(R.string.settings_model)) },
            supportingText = { Text(stringResource(R.string.settings_model_hint)) },
            singleLine = true,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = {
            scope.launch {
                container.settings.setModelName(model)
                container.aiVerified.value = false
            }
        }) { Text(stringResource(R.string.settings_save)) }
    }

    if (settings.aiSource == AiSource.OWN_KEY) {
        var apiKeyInput by remember { mutableStateOf("") }
        OutlinedTextField(
            value = apiKeyInput,
            onValueChange = { apiKeyInput = it },
            label = { Text(stringResource(R.string.settings_api_key)) },
            supportingText = { Text(stringResource(R.string.settings_api_key_hint)) },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = {
                    scope.launch {
                        container.settings.setApiKey(apiKeyInput)
                        apiKeyInput = ""
                        container.aiVerified.value = false
                    }
                },
                enabled = apiKeyInput.isNotBlank(),
            ) { Text(stringResource(R.string.settings_save)) }
            TextButton(
                onClick = {
                    scope.launch {
                        container.settings.setApiKey("")
                        container.aiVerified.value = false
                    }
                },
                enabled = settings.apiKeyEncrypted.isNotEmpty(),
            ) { Text(stringResource(R.string.settings_remove)) }
        }
        Text(
            text = stringResource(
                if (settings.apiKeyEncrypted.isNotEmpty()) R.string.settings_api_key_saved else R.string.settings_api_key_none,
            ),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    LabeledChips(
        label = R.string.settings_default_mode,
        options = AnswerMode.entries.map { it to it.labelRes },
        selected = settings.answerMode,
    ) { mode -> scope.launch { container.settings.setAnswerMode(mode) } }

    // Tes koneksi: status AI baru dianggap aktif setelah satu jawaban sungguhan diterima.
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    OutlinedButton(
        onClick = {
            testing = true
            testResult = null
            scope.launch {
                testResult = try {
                    container.aiRepository.ask(AnswerMode.SHORT, emptyList(), "Balas hanya dengan satu kata: OK", null)
                    context.getString(R.string.settings_test_ok)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    context.getString(R.string.settings_test_fail, describeError(context, e))
                }
                testing = false
            }
        },
        enabled = !testing,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(stringResource(if (testing) R.string.settings_testing else R.string.settings_test_ai)) }
    testResult?.let {
        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (BuildConfig.DEBUG && settings.aiSource == AiSource.FIREBASE) {
        var token by remember { mutableStateOf<String?>(null) }
        Text(stringResource(R.string.settings_appcheck_token), style = MaterialTheme.typography.titleSmall)
        Text(
            text = stringResource(R.string.settings_appcheck_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = {
                scope.launch {
                    AppCheckInstaller.warmUp()
                    delay(1500)
                    token = AppCheckInstaller.debugToken(context).orEmpty()
                }
            }) { Text(stringResource(R.string.settings_appcheck_show)) }
            val shown = token
            if (!shown.isNullOrEmpty()) {
                TextButton(onClick = { copyToClipboard(context, shown) }) { Text(stringResource(R.string.chat_copy)) }
            }
        }
        val shown = token
        if (shown != null) {
            Text(
                text = shown.ifEmpty { stringResource(R.string.settings_appcheck_none) },
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun HistorySection(settings: AppSettings, container: AppContainer, scope: CoroutineScope, onClear: () -> Unit) {
    SectionTitle(R.string.settings_history)
    SwitchRow(R.string.settings_save_history, settings.saveHistory) { scope.launch { container.settings.setSaveHistory(it) } }
    OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.settings_clear_history))
    }
}
