package com.fadrol.ai.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fadrol.ai.AppContainer

class ChatViewModel(private val container: AppContainer) : ViewModel() {

    val controller = ChatController(container, viewModelScope, "app")

    /** Mengambil titipan dari layar Scan atau Target nilai (sekali pakai) dan langsung mengirimkannya. */
    fun consumePending() {
        val pending = container.pendingChat.value ?: return
        container.pendingChat.value = null
        controller.startFrom(pending)
    }

    override fun onCleared() {
        controller.close()
    }
}
