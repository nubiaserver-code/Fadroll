@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.components

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.fadrol.ai.AppContainer
import com.fadrol.ai.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

enum class ScanStep { EDIT, REVIEW }

enum class ScanSend { TEXT, IMAGE }

/**
 * Alur: pangkas gambar, baca teks (OCR), periksa/edit hasil, konfirmasi, lalu kirim ke AI.
 * State ini tidak menyimpan gambar ke disk dan dipakai di halaman Scan maupun panel mengambang.
 */
class ScanFlowState(
    private val container: AppContainer,
    private val scope: CoroutineScope,
) {
    var original by mutableStateOf<Bitmap?>(null)
        private set
    var cropped by mutableStateOf<Bitmap?>(null)
        private set
    var step by mutableStateOf(ScanStep.EDIT)
        private set
    var ocrText by mutableStateOf("")
    var ocrRunning by mutableStateOf(false)
        private set
    var blurry by mutableStateOf(false)
        private set
    var noText by mutableStateOf(false)
        private set
    var ocrFailed by mutableStateOf(false)
        private set
    var suspectedBlocked by mutableStateOf(false)
        private set
    var pendingSend by mutableStateOf<ScanSend?>(null)

    val hasImage: Boolean get() = original != null

    fun start(bitmap: Bitmap, blocked: Boolean = false) {
        original = bitmap
        cropped = null
        step = ScanStep.EDIT
        ocrText = ""
        blurry = false
        noText = false
        ocrFailed = false
        suspectedBlocked = blocked
        pendingSend = null
    }

    fun backToEdit() {
        step = ScanStep.EDIT
        pendingSend = null
    }

    fun applyCrop(bitmap: Bitmap) {
        cropped = bitmap
        step = ScanStep.REVIEW
        runOcr(bitmap)
    }

    fun clear() {
        original = null
        cropped = null
        ocrText = ""
        step = ScanStep.EDIT
        pendingSend = null
    }

    private fun runOcr(bitmap: Bitmap) {
        ocrRunning = true
        ocrFailed = false
        scope.launch {
            try {
                val result = container.ocr.read(bitmap)
                ocrText = result.text
                noText = result.text.isBlank()
                blurry = result.sharpness < BLUR_THRESHOLD
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ocrFailed = true
            } finally {
                ocrRunning = false
            }
        }
    }

    companion object {
        const val BLUR_THRESHOLD = 60.0
    }
}

@Composable
fun ScanFlow(
    state: ScanFlowState,
    onSend: (prompt: String, image: Bitmap?) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    onUseForTarget: (() -> Unit)? = null,
) {
    val original = state.original ?: return
    when (state.step) {
        ScanStep.EDIT -> CropEditor(
            bitmap = original,
            onConfirm = state::applyCrop,
            onCancel = onClose,
            modifier = modifier,
            blockedWarning = state.suspectedBlocked,
        )

        ScanStep.REVIEW -> ReviewStep(state, onSend, onUseForTarget, modifier)
    }
}

private fun imagePrompt(context: Context, ocr: String): String {
    val base = context.getString(R.string.scan_image_prompt)
    val text = ocr.trim()
    return if (text.isEmpty()) base else base + "\n\n" + context.getString(R.string.scan_ocr_hint) + "\n" + text
}

@Composable
private fun Warning(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
}

@Composable
private fun ReviewStep(
    state: ScanFlowState,
    onSend: (String, Bitmap?) -> Unit,
    onUseForTarget: (() -> Unit)?,
    modifier: Modifier,
) {
    val context = LocalContext.current
    val cropped = state.cropped
    val pending = state.pendingSend
    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (cropped != null) {
            val preview = remember(cropped) { cropped.asImageBitmap() }
            Image(
                bitmap = preview,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
                    .clip(RoundedCornerShape(12.dp)),
            )
        }
        if (state.suspectedBlocked) Warning(stringResource(R.string.capture_blocked_warning))

        if (state.ocrRunning) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.scan_reading), style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            if (state.ocrFailed) {
                Warning(stringResource(R.string.scan_warn_failed))
            } else if (state.noText) {
                Warning(stringResource(R.string.scan_warn_empty))
            } else if (state.blurry) {
                Warning(stringResource(R.string.scan_warn_blur))
            }
            OutlinedTextField(
                value = state.ocrText,
                onValueChange = { state.ocrText = it },
                label = { Text(stringResource(R.string.scan_text_label)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp),
            )
            Text(
                text = stringResource(R.string.scan_complex_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (pending != null) {
            // Konfirmasi eksplisit: tidak ada teks atau gambar yang dikirim ke AI sebelum tombol Kirim ditekan.
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                shape = RoundedCornerShape(16.dp),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(stringResource(R.string.scan_confirm_title), style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = stringResource(
                            if (pending == ScanSend.TEXT) R.string.scan_confirm_text_body else R.string.scan_confirm_image_body,
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { state.pendingSend = null }) { Text(stringResource(R.string.cancel)) }
                        Button(onClick = {
                            state.pendingSend = null
                            if (pending == ScanSend.TEXT) {
                                onSend(state.ocrText.trim(), null)
                            } else {
                                onSend(imagePrompt(context, state.ocrText), cropped)
                            }
                        }) {
                            Text(stringResource(R.string.chat_confirm_send))
                        }
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    onClick = { state.pendingSend = ScanSend.TEXT },
                    enabled = !state.ocrRunning && state.ocrText.isNotBlank(),
                    modifier = Modifier.weight(1f),
                ) { Text(stringResource(R.string.scan_analyze_text)) }
                Button(
                    onClick = { state.pendingSend = ScanSend.IMAGE },
                    enabled = !state.ocrRunning && cropped != null,
                    modifier = Modifier.weight(1f),
                ) { Text(stringResource(R.string.scan_analyze_image)) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = state::backToEdit) { Text(stringResource(R.string.scan_back_to_crop)) }
                if (onUseForTarget != null) {
                    TextButton(
                        onClick = {
                            state.ocrText.takeIf { it.isNotBlank() }?.let { onUseForTarget() }
                        },
                        enabled = state.ocrText.isNotBlank(),
                    ) { Text(stringResource(R.string.scan_use_target)) }
                }
            }
        }
    }
}
