package com.fadrol.ai.network

import android.graphics.Bitmap
import android.net.Uri
import com.fadrol.ai.ai.AiErrorKind
import com.fadrol.ai.ai.AiException
import com.fadrol.ai.ai.AiService
import com.fadrol.ai.ai.ChatTurn
import com.fadrol.ai.ocr.ImageUtils
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Gemini API lewat HTTPS dengan API key milik pengguna (disimpan terenkripsi di perangkat, bukan di APK).
 * Berguna untuk mencoba AI tanpa menyiapkan proyek Firebase.
 */
class GeminiRestService(
    private val apiKey: String,
    private val modelName: String,
) : AiService {

    override suspend fun generate(
        system: String,
        history: List<ChatTurn>,
        prompt: String,
        image: Bitmap?,
        json: Boolean,
    ): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw AiException(AiErrorKind.NO_API_KEY)
        val body = buildBody(system, history, prompt, image, json)
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Uri.encode(modelName)}:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw AiException(AiErrorKind.API, httpErrorMessage(code, text))
            parseAnswer(text)
        } catch (e: AiException) {
            throw e
        } catch (e: IOException) {
            throw AiException(AiErrorKind.NETWORK, e.message, e)
        } finally {
            conn.disconnect()
        }
    }

    private fun buildBody(
        system: String,
        history: List<ChatTurn>,
        prompt: String,
        image: Bitmap?,
        json: Boolean,
    ): String {
        val root = JSONObject()
        root.put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))),
        )
        val contents = JSONArray()
        for (turn in history) {
            contents.put(
                JSONObject()
                    .put("role", turn.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", turn.text))),
            )
        }
        val parts = JSONArray()
        if (image != null) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", ImageUtils.toBase64Jpeg(image)),
                ),
            )
        }
        parts.put(JSONObject().put("text", prompt))
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        root.put("contents", contents)
        if (json) {
            root.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        }
        return root.toString()
    }

    private fun parseAnswer(raw: String): String {
        val root = JSONObject(raw)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            if (reason.isNotEmpty()) throw AiException(AiErrorKind.API, "Diblokir: $reason")
            throw AiException(AiErrorKind.EMPTY)
        }
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue
                sb.append(part.optString("text", ""))
            }
        }
        val out = sb.toString().trim()
        if (out.isEmpty()) throw AiException(AiErrorKind.EMPTY)
        return out
    }

    private fun httpErrorMessage(code: Int, raw: String): String {
        val message = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) {
            ""
        }
        val hint = when (code) {
            400 -> "permintaan ditolak (cek API key dan nama model)"
            401, 403 -> "API key ditolak atau tidak punya akses"
            404 -> "model tidak ditemukan, cek nama model di Pengaturan"
            429 -> "kuota atau batas permintaan terlampaui"
            else -> "server menolak permintaan"
        }
        return "HTTP $code, $hint. ${message.take(240)}".trim()
    }
}
