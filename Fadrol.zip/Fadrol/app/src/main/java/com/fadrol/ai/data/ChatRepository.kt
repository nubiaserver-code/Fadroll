package com.fadrol.ai.data

import com.fadrol.ai.ai.AnswerMode
import kotlinx.coroutines.flow.Flow

data class LoadedConversation(
    val conversation: ConversationEntity,
    val messages: List<MessageEntity>,
)

class ChatRepository(private val dao: FadrolDao) {

    fun conversations(query: String): Flow<List<ConversationEntity>> =
        if (query.isBlank()) dao.observeAll() else dao.search(query.trim())

    fun recent(limit: Int): Flow<List<ConversationEntity>> = dao.observeRecent(limit)

    suspend fun create(
        title: String,
        source: String,
        mode: AnswerMode,
        targetJson: String? = null,
    ): Long {
        val now = System.currentTimeMillis()
        return dao.insertConversation(
            ConversationEntity(
                title = title.trim().take(60).ifEmpty { "Fadrol" },
                source = source,
                mode = mode.key,
                createdAt = now,
                updatedAt = now,
                targetJson = targetJson,
            ),
        )
    }

    suspend fun addMessage(conversationId: Long, role: String, text: String, hasImage: Boolean = false): Long {
        val now = System.currentTimeMillis()
        val id = dao.insertMessage(
            MessageEntity(
                conversationId = conversationId,
                role = role,
                text = text,
                hasImage = hasImage,
                createdAt = now,
            ),
        )
        dao.touch(conversationId, now)
        return id
    }

    suspend fun load(id: Long): LoadedConversation? {
        val conversation = dao.getConversation(id) ?: return null
        return LoadedConversation(conversation, dao.getMessages(id))
    }

    suspend fun setTarget(id: Long, json: String) = dao.setTargetJson(id, json)

    suspend fun delete(id: Long) = dao.deleteConversation(id)

    suspend fun deleteAll() = dao.deleteAll()
}
