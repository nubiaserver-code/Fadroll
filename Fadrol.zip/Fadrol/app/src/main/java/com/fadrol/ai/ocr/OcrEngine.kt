package com.fadrol.ai.ocr

import android.graphics.Bitmap
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

data class OcrResult(
    val text: String,
    /** Variansi Laplacian; di bawah ~60 biasanya gambar buram. */
    val sharpness: Double,
)

/** OCR dengan Google ML Kit Text Recognition (model Latin, berjalan di perangkat). */
class OcrEngine {

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    suspend fun read(bitmap: Bitmap): OcrResult {
        val result = recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
        // Urutan blok dan baris dipertahankan agar nomor soal dan pilihan jawaban tetap berurutan.
        val text = result.textBlocks
            .joinToString("\n\n") { block -> block.lines.joinToString("\n") { it.text } }
            .trim()
        val sharp = withContext(Dispatchers.Default) { ImageUtils.sharpness(bitmap) }
        return OcrResult(text, sharp)
    }
}

private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { value -> cont.resume(value) }
    addOnFailureListener { error -> cont.resumeWithException(error) }
    addOnCanceledListener { cont.cancel() }
}
