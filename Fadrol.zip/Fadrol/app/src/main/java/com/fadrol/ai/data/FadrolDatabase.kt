package com.fadrol.ai.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    /** app, floating, scan, atau target. */
    val source: String,
    val mode: String,
    val createdAt: Long,
    val updatedAt: Long,
    /** Pengaturan simulasi Target nilai (JSON) bila percakapan berasal dari fitur itu. */
    val targetJson: String? = null,
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("conversationId")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    /** user atau model. */
    val role: String,
    val text: String,
    /** Hanya penanda bahwa pesan memakai gambar. Gambarnya sendiri tidak pernah disimpan. */
    val hasImage: Boolean = false,
    val createdAt: Long,
)

@Dao
interface FadrolDao {
    @Insert
    suspend fun insertConversation(entity: ConversationEntity): Long

    @Insert
    suspend fun insertMessage(entity: MessageEntity): Long

    @Query("UPDATE conversations SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("UPDATE conversations SET targetJson = :json WHERE id = :id")
    suspend fun setTargetJson(id: Long, json: String)

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<ConversationEntity>>

    @Query(
        "SELECT DISTINCT c.* FROM conversations AS c " +
            "LEFT JOIN messages AS m ON m.conversationId = c.id " +
            "WHERE c.title LIKE '%' || :query || '%' OR m.text LIKE '%' || :query || '%' " +
            "ORDER BY c.updatedAt DESC",
    )
    fun search(query: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun getConversation(id: Long): ConversationEntity?

    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY id ASC")
    suspend fun getMessages(id: Long): List<MessageEntity>

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: Long)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()
}

@Database(entities = [ConversationEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class FadrolDatabase : RoomDatabase() {
    abstract fun dao(): FadrolDao

    companion object {
        fun build(context: Context): FadrolDatabase =
            Room.databaseBuilder(context.applicationContext, FadrolDatabase::class.java, "fadrol.db").build()
    }
}
