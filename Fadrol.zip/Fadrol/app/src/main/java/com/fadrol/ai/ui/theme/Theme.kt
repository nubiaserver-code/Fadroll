package com.fadrol.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fadrol.ai.settings.ThemeMode

// Dark: hitam dan abu-abu gelap. Light: putih dan abu-abu terang. Aksen: ungu kebiruan.
private val DarkColors = darkColorScheme(
    primary = Color(0xFF8E86FF),
    onPrimary = Color(0xFF13103D),
    primaryContainer = Color(0xFF2B2870),
    onPrimaryContainer = Color(0xFFE4E1FF),
    secondary = Color(0xFF7C9BFF),
    onSecondary = Color(0xFF0C1B4D),
    secondaryContainer = Color(0xFF222B52),
    onSecondaryContainer = Color(0xFFDCE3FF),
    background = Color(0xFF0D0E12),
    onBackground = Color(0xFFE8E8EE),
    surface = Color(0xFF14161B),
    onSurface = Color(0xFFE8E8EE),
    surfaceVariant = Color(0xFF1E2027),
    onSurfaceVariant = Color(0xFFB4B7C3),
    surfaceContainerLowest = Color(0xFF0A0B0E),
    surfaceContainerLow = Color(0xFF111318),
    surfaceContainer = Color(0xFF181A20),
    surfaceContainerHigh = Color(0xFF1F2229),
    surfaceContainerHighest = Color(0xFF272A32),
    outline = Color(0xFF3B3F4A),
    outlineVariant = Color(0xFF2A2D36),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF3A0905),
    errorContainer = Color(0xFF4A1F1C),
    onErrorContainer = Color(0xFFFFDAD6),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B50F0),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE5E2FF),
    onPrimaryContainer = Color(0xFF1B1560),
    secondary = Color(0xFF3F5BFF),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDDE3FF),
    onSecondaryContainer = Color(0xFF0B1B66),
    background = Color(0xFFF6F6FA),
    onBackground = Color(0xFF15161B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF15161B),
    surfaceVariant = Color(0xFFECECF3),
    onSurfaceVariant = Color(0xFF5A5D6B),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF9F9FC),
    surfaceContainer = Color(0xFFF1F1F7),
    surfaceContainerHigh = Color(0xFFEBEBF2),
    surfaceContainerHighest = Color(0xFFE4E4ED),
    outline = Color(0xFFC5C7D3),
    outlineVariant = Color(0xFFDADCE5),
    error = Color(0xFFB3261E),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

private val FadrolTypography = Typography().let { base ->
    base.copy(
        headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = (-0.4).sp),
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.copy(lineHeight = 24.sp),
        bodyMedium = base.bodyMedium.copy(lineHeight = 21.sp),
        labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Medium),
    )
}

private val FadrolShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun FadrolTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = FadrolTypography,
        shapes = FadrolShapes,
        content = content,
    )
}
