@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.fadrol.ai.R
import com.fadrol.ai.ai.AiErrorKind
import com.fadrol.ai.ai.AiException
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.chat.ChatController
import com.fadrol.ai.chat.UiMessage
import kotlinx.coroutines.delay

@get:StringRes
val AnswerMode.labelRes: Int
    get() = when (this) {
        AnswerMode.SHORT -> R.string.mode_short
        AnswerMode.FULL -> R.string.mode_full
        AnswerMode.LEARN -> R.string.mode_learn
    }

fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText("Fadrol", text))
}

/** Menerjemahkan galat AI ke pesan yang jelas dan memberi tahu langkah berikutnya. */
fun describeError(context: Context, error: Throwable): String {
    if (error !is AiException) return context.getString(R.string.err_unknown, error.message.orEmpty().take(300))
    return when (error.kind) {
        AiErrorKind.FIREBASE_NOT_CONFIGURED -> context.getString(R.string.err_firebase_not_configured)
        AiErrorKind.NO_API_KEY -> context.getString(R.string.err_no_api_key)
        AiErrorKind.NETWORK -> context.getString(R.string.err_network)
        AiErrorKind.EMPTY -> context.getString(R.string.err_empty)
        AiErrorKind.API -> context.getString(R.string.err_api, error.detail.orEmpty().take(300))
    }
}

@Composable
fun ModeSelector(mode: AnswerMode, onChange: (AnswerMode) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AnswerMode.entries.forEach { item ->
            FilterChip(
                selected = mode == item,
                onClick = { onChange(item) },
                label = { Text(stringResource(item.labelRes)) },
            )
        }
    }
}

@Composable
fun MessageBubble(message: UiMessage, compact: Boolean, modifier: Modifier = Modifier) {
    val isUser = message.role == "user"
    val context = LocalContext.current
    var copied by remember(message.id) { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    val codeBackground = MaterialTheme.colorScheme.surfaceContainerHighest
    val content = remember(message.text, isUser, codeBackground) {
        if (isUser) AnnotatedString(message.text) else markdownToAnnotated(message.text, codeBackground)
    }
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(18.dp, 18.dp, if (isUser) 4.dp else 18.dp, if (isUser) 18.dp else 4.dp),
            modifier = Modifier.widthIn(max = 560.dp),
        ) {
            Text(
                text = content,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                style = if (compact) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodyLarge,
            )
        }
        if (!isUser) {
            TextButton(onClick = {
                copyToClipboard(context, message.text)
                copied = true
            }) {
                Text(stringResource(if (copied) R.string.chat_copied else R.string.chat_copy))
            }
        } else if (message.hasImage) {
            Text(
                text = stringResource(R.string.chat_image_attached),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp, end = 4.dp),
            )
        }
    }
}

/**
 * Isi percakapan yang dipakai bersama oleh halaman AI Chat dan panel mengambang.
 * Tidak memakai Dialog atau Popup agar aman ditampilkan di jendela overlay milik service.
 */
@Composable
fun ChatBody(
    controller: ChatController,
    onPickGallery: () -> Unit,
    onPickCamera: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    onReadScreen: (() -> Unit)? = null,
    onTargetScore: (() -> Unit)? = null,
    notice: Int? = null,
    onDismissNotice: () -> Unit = {},
) {
    val context = LocalContext.current
    val messages by controller.messages.collectAsState()
    val loading by controller.loading.collectAsState()
    val error by controller.error.collectAsState()
    val mode by controller.mode.collectAsState()
    val pendingImage by controller.pendingImage.collectAsState()
    val confirming by controller.awaitingImageConfirm.collectAsState()
    val listState = rememberLazyListState()
    val itemCount = messages.size + if (loading) 1 else 0

    LaunchedEffect(itemCount) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    val image = pendingImage
    val failure = error

    Column(modifier.fillMaxWidth()) {
        ModeSelector(
            mode = mode,
            onChange = controller::setMode,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (itemCount == 0) {
                EmptyChat(compact)
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(messages, key = { it.id }) { message -> MessageBubble(message, compact) }
                    if (loading) item { ThinkingRow() }
                }
            }
        }
        if (notice != null) InfoBar(stringResource(notice), isError = false, onDismiss = onDismissNotice)
        if (failure != null) InfoBar(describeError(context, failure), isError = true, onDismiss = controller::dismissError)
        if (image != null && !confirming) PendingImageRow(image, onRemove = controller::clearImage)
        if (confirming) {
            ConfirmBar(
                onConfirm = { if (controller.send(controller.input, confirmed = true)) controller.input = "" },
                onCancel = controller::cancelConfirm,
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AssistChip(onClick = onPickGallery, label = { Text(stringResource(R.string.chat_action_gallery)) })
            AssistChip(onClick = onPickCamera, label = { Text(stringResource(R.string.chat_action_camera)) })
            if (onReadScreen != null) {
                AssistChip(onClick = onReadScreen, label = { Text(stringResource(R.string.chat_action_screen)) })
            }
            if (onTargetScore != null) {
                AssistChip(onClick = onTargetScore, label = { Text(stringResource(R.string.chat_action_target)) })
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 10.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = controller.input,
                onValueChange = { controller.input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.chat_input_hint)) },
                maxLines = 4,
                shape = RoundedCornerShape(22.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = { if (controller.send(controller.input)) controller.input = "" },
                enabled = !loading && (controller.input.isNotBlank() || image != null),
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.chat_send))
            }
        }
    }
}

@Composable
private fun EmptyChat(compact: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (!compact) {
            FadrolLogo(56.dp)
            Spacer(Modifier.size(16.dp))
        }
        Text(
            text = stringResource(R.string.chat_empty_title),
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.size(6.dp))
        Text(
            text = stringResource(R.string.chat_empty_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ThinkingRow() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = stringResource(R.string.chat_thinking),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun InfoBar(text: String, isError: Boolean, onDismiss: () -> Unit) {
    Surface(
        color = if (isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
        contentColor = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.err_dismiss)) }
        }
    }
}

@Composable
private fun PendingImageRow(bitmap: Bitmap, onRemove: () -> Unit) {
    val preview = remember(bitmap) { bitmap.asImageBitmap() }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            bitmap = preview,
            contentDescription = stringResource(R.string.chat_image_attached),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(10.dp)),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = stringResource(R.string.chat_image_attached),
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onRemove) { Text(stringResource(R.string.chat_image_remove)) }
    }
}

/** Konfirmasi eksplisit sebelum gambar dikirim ke AI. */
@Composable
private fun ConfirmBar(onConfirm: () -> Unit, onCancel: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(stringResource(R.string.chat_confirm_image_title), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.size(4.dp))
            Text(stringResource(R.string.chat_confirm_image_body), style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) }
                Button(onClick = onConfirm) { Text(stringResource(R.string.chat_confirm_send)) }
            }
        }
    }
}
