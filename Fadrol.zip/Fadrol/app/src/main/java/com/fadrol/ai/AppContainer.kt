package com.fadrol.ai

import android.app.Application
import android.graphics.Bitmap
import com.fadrol.ai.ai.AiRepository
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.data.ChatRepository
import com.fadrol.ai.data.FadrolDatabase
import com.fadrol.ai.ocr.OcrEngine
import com.fadrol.ai.settings.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow

/** Permintaan kirim ke AI Chat yang dititipkan dari layar lain (Scan, Target nilai). Hanya di memori. */
data class PendingChat(
    val prompt: String,
    val image: Bitmap? = null,
    val mode: AnswerMode? = null,
    val source: String = "app",
)

/** Satu wadah layanan untuk seluruh aplikasi, dipakai bersama oleh UI, panel mengambang, dan service. */
class AppContainer(val app: Application) {
    val settings = SettingsStore(app)
    val database: FadrolDatabase by lazy { FadrolDatabase.build(app) }
    val chatRepository: ChatRepository by lazy { ChatRepository(database.dao()) }

    /** True setelah ada satu jawaban AI yang berhasil diterima pada sesi ini. */
    val aiVerified = MutableStateFlow(false)
    val aiRepository: AiRepository by lazy { AiRepository(app, settings, aiVerified) }
    val ocr: OcrEngine by lazy { OcrEngine() }

    /** Serah-terima antar layar. Tidak pernah ditulis ke disk, sehingga screenshot tidak tersimpan. */
    val pendingChat = MutableStateFlow<PendingChat?>(null)
    val lastOcrText = MutableStateFlow<String?>(null)
}
