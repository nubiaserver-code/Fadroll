package com.fadrol.ai.targetscore

import java.text.DecimalFormat
import kotlin.math.abs
import kotlin.math.round

enum class AnswerState { UNANSWERED, CORRECT, WRONG }

/**
 * Pengaturan penilaian.
 *
 * Skor = nilaiAwal + (bobotBenar - penalti x bobotSalah) / totalBobot x (100 - nilaiAwal), dibatasi 0..100.
 * Dengan nilai awal 0, bobot sama, dan tanpa penalti rumusnya menjadi: benar / jumlahSoal x 100.
 */
data class ScoreConfig(
    val target: Double,
    val weights: List<Double>,
    val initialScore: Double = 0.0,
    /** Pecahan bobot soal yang dikurangkan untuk tiap jawaban salah (0.25 berarti minus seperempat). */
    val wrongPenalty: Double = 0.0,
) {
    val count: Int get() = weights.size
    val totalWeight: Double get() = weights.sum()
    val headroom: Double get() = MAX_SCORE - initialScore
    val equalWeights: Boolean get() = weights.isEmpty() || weights.all { abs(it - weights[0]) < 1e-9 }

    companion object {
        const val MAX_SCORE = 100.0
    }
}

data class SimulationResult(
    val score: Double,
    val correct: Int,
    val wrong: Int,
    val unanswered: Int,
    /** Skor / target. 1.0 berarti tepat di target. Bila target 0, nilainya 1.0. */
    val targetProgress: Double,
    /** Skor dikurangi target. Positif berarti melampaui target. */
    val gap: Double,
)

data class Requirement(
    /** Bobot bersih yang harus dikumpulkan dari soal agar target tercapai. */
    val neededWeight: Double,
    /** Jumlah benar paling sedikit (bila yang benar soal berbobot terbesar), sisanya dikosongkan. */
    val minCorrect: Int,
    /** Jumlah benar yang pasti cukup soal mana pun yang benar (soal berbobot terkecil), sisanya dikosongkan. */
    val safeCorrect: Int,
    /** Seperti minCorrect, tetapi semua soal yang tidak benar dijawab salah (penalti berlaku). */
    val minCorrectIfRestWrong: Int,
    /** Seperti safeCorrect, tetapi semua soal yang tidak benar dijawab salah. */
    val safeCorrectIfRestWrong: Int,
    val hasPenalty: Boolean,
    val equalWeights: Boolean,
    /** Target sudah terpenuhi oleh nilai awal sehingga tidak butuh jawaban benar. */
    val alreadyMet: Boolean,
)

data class StateStatus(
    /** Skor tertinggi yang masih mungkin bila semua soal yang belum dijawab dijawab benar. */
    val bestPossibleScore: Double,
    val reachable: Boolean,
    /** Jawaban benar tambahan paling sedikit dari soal yang belum dijawab. Null bila target mustahil. */
    val moreCorrectNeeded: Int?,
    val unansweredLeft: Int,
)

object TargetScoreCalculator {

    const val MAX_QUESTIONS = 200
    private const val EPS = 1e-9

    fun equalWeights(count: Int): List<Double> = List(count) { 1.0 }

    /** Pisahkan dengan spasi, koma, titik koma, atau baris baru. Desimal memakai titik. Null bila tidak valid. */
    fun parseWeights(text: String): List<Double>? {
        val parts = text.split(Regex("[\\s,;]+")).filter { it.isNotBlank() }
        if (parts.isEmpty() || parts.size > MAX_QUESTIONS) return null
        val out = ArrayList<Double>(parts.size)
        for (part in parts) {
            val value = part.toDoubleOrNull() ?: return null
            if (value.isNaN() || value.isInfinite() || value <= 0.0) return null
            out.add(value)
        }
        return out
    }

    fun simulate(config: ScoreConfig, states: List<AnswerState>): SimulationResult {
        var earned = 0.0
        var lost = 0.0
        var correct = 0
        var wrong = 0
        for (i in config.weights.indices) {
            val state = states.getOrNull(i) ?: AnswerState.UNANSWERED
            if (state == AnswerState.CORRECT) {
                earned += config.weights[i]
                correct++
            } else if (state == AnswerState.WRONG) {
                lost += config.weights[i]
                wrong++
            }
        }
        val score = scoreFor(config, earned - config.wrongPenalty * lost)
        val progress = if (config.target <= 0.0) 1.0 else score / config.target
        return SimulationResult(
            score = score,
            correct = correct,
            wrong = wrong,
            unanswered = config.count - correct - wrong,
            targetProgress = progress,
            gap = score - config.target,
        )
    }

    fun requirement(config: ScoreConfig): Requirement {
        val total = config.totalWeight
        val raw = rawNeededWeight(config)
        val needed = maxOf(0.0, raw)
        val desc = config.weights.sortedDescending()
        val asc = config.weights.sorted()
        val p = config.wrongPenalty
        // Bila semua soal yang tidak benar dijawab salah: (1 + p) x bobotBenar - p x total >= raw.
        // raw sengaja tidak dipotong di nol: dengan penalti, skor bisa turun di bawah nilai awal.
        // Target 0 selalu terpenuhi karena skor dibatasi minimal 0.
        val neededIfRestWrong = if (config.target <= EPS) 0.0 else (raw + p * total) / (1.0 + p)
        return Requirement(
            neededWeight = needed,
            minCorrect = countFor(desc, needed),
            safeCorrect = countFor(asc, needed),
            minCorrectIfRestWrong = countFor(desc, neededIfRestWrong),
            safeCorrectIfRestWrong = countFor(asc, neededIfRestWrong),
            hasPenalty = p > 0.0,
            equalWeights = config.equalWeights,
            alreadyMet = raw <= EPS,
        )
    }

    fun status(config: ScoreConfig, states: List<AnswerState>): StateStatus {
        var banked = 0.0
        val open = ArrayList<Double>()
        for (i in config.weights.indices) {
            val w = config.weights[i]
            val state = states.getOrNull(i) ?: AnswerState.UNANSWERED
            if (state == AnswerState.CORRECT) {
                banked += w
            } else if (state == AnswerState.WRONG) {
                banked -= config.wrongPenalty * w
            } else {
                open.add(w)
            }
        }
        val best = scoreFor(config, banked + open.sum())
        val reachable = best + EPS >= config.target
        val more: Int? = if (!reachable) {
            null
        } else {
            val gap = rawNeededWeight(config) - banked
            if (config.target <= EPS || gap <= EPS) 0 else countFor(open.sortedDescending(), gap)
        }
        return StateStatus(best, reachable, more, open.size)
    }

    private fun scoreFor(config: ScoreConfig, netWeight: Double): Double {
        val raw = config.initialScore + netWeight / config.totalWeight * config.headroom
        return raw.coerceIn(0.0, ScoreConfig.MAX_SCORE)
    }

    /** Bobot bersih yang dibutuhkan agar skor >= target. Bisa negatif bila target di bawah nilai awal. */
    private fun rawNeededWeight(config: ScoreConfig): Double {
        if (config.headroom <= EPS) return 0.0
        return (config.target - config.initialScore) / config.headroom * config.totalWeight
    }

    /** Jumlah soal terkecil dari daftar terurut yang bobot kumulatifnya mencapai kebutuhan. */
    private fun countFor(sorted: List<Double>, need: Double): Int {
        if (need <= EPS) return 0
        var acc = 0.0
        for ((index, weight) in sorted.withIndex()) {
            acc += weight
            if (acc + EPS >= need) return index + 1
        }
        return sorted.size
    }

    /** Angka bulat ditampilkan tanpa desimal; selain itu maksimal dua desimal sesuai bahasa perangkat. */
    fun formatNumber(value: Double): String {
        val rounded = round(value * 100.0) / 100.0
        if (abs(rounded - round(rounded)) < 1e-9) return round(rounded).toLong().toString()
        return DecimalFormat("0.##").format(rounded)
    }
}
