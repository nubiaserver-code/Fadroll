package com.fadrol.ai.capture

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

enum class CaptureFailure { ERROR, TIMEOUT }

sealed interface CaptureEvent {
    /** Sesaat sebelum frame diambil; overlay Fadrol disembunyikan agar tidak ikut tertangkap. */
    data object Capturing : CaptureEvent

    class Captured(val bitmap: Bitmap, val suspectedBlocked: Boolean) : CaptureEvent

    class Failed(val reason: CaptureFailure) : CaptureEvent

    data object Cancelled : CaptureEvent
}

/** Jembatan antara ScreenCaptureActivity/Service dan FloatingService (satu proses). Gambar hanya di memori. */
object CaptureCoordinator {
    private val _events = MutableSharedFlow<CaptureEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<CaptureEvent> = _events.asSharedFlow()

    fun emit(event: CaptureEvent) {
        _events.tryEmit(event)
    }
}

/** Mengirim gambar dari ImagePickerActivity (galeri/kamera) ke panel mengambang. */
object ImageBus {
    private val _images = MutableSharedFlow<Bitmap>(extraBufferCapacity = 1)
    val images: SharedFlow<Bitmap> = _images.asSharedFlow()

    fun emit(bitmap: Bitmap) {
        _images.tryEmit(bitmap)
    }
}
