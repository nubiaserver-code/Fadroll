package com.fadrol.ai.chat

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.fadrol.ai.AppContainer
import com.fadrol.ai.PendingChat
import com.fadrol.ai.R
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.ai.ChatTurn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiMessage(
    val id: Long,
    val role: String,
    val text: String,
    val hasImage: Boolean = false,
)

/**
 * Logika percakapan yang dipakai bersama oleh halaman AI Chat dan panel mengambang.
 * Setiap instance punya percakapan sendiri (source "app" atau "floating"), jadi konteksnya tidak tercampur,
 * tetapi keduanya memakai AiRepository dan database yang sama.
 */
class ChatController(
    private val container: AppContainer,
    private val scope: CoroutineScope,
    private val source: String,
) {
    private val _messages = MutableStateFlow<List<UiMessage>>(emptyList())
    val messages: StateFlow<List<UiMessage>> = _messages.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<Throwable?>(null)
    val error: StateFlow<Throwable?> = _error.asStateFlow()

    private val _mode = MutableStateFlow(AnswerMode.FULL)
    val mode: StateFlow<AnswerMode> = _mode.asStateFlow()

    /** Gambar yang menunggu dikirim. Hanya di memori; tidak pernah disimpan. */
    val pendingImage = MutableStateFlow<Bitmap?>(null)

    /** True saat pengguna menekan Kirim dengan gambar terlampir dan harus menyetujui pengiriman dulu. */
    val awaitingImageConfirm = MutableStateFlow(false)

    var input by mutableStateOf("")

    /** Id percakapan yang sedang aktif (null bila belum disimpan). Berupa state agar UI ikut berubah. */
    var conversationId by mutableStateOf<Long?>(null)
        private set

    private var job: Job? = null
    private var localId = -1L
    private var modeTouched = false
    private var sourceOverride: String? = null

    init {
        scope.launch {
            val saved = container.settings.snapshot().answerMode
            if (!modeTouched) _mode.value = saved
        }
    }

    fun setMode(value: AnswerMode) {
        modeTouched = true
        _mode.value = value
    }

    fun attachImage(bitmap: Bitmap) {
        pendingImage.value = bitmap
        awaitingImageConfirm.value = false
    }

    fun clearImage() {
        pendingImage.value = null
        awaitingImageConfirm.value = false
    }

    fun cancelConfirm() {
        awaitingImageConfirm.value = false
    }

    fun dismissError() {
        _error.value = null
    }

    /**
     * Mengirim pesan. Bila ada gambar terlampir dan belum disetujui, hanya meminta konfirmasi (return false).
     * @return true bila pesan benar-benar dikirim sehingga kolom input boleh dikosongkan.
     */
    fun send(text: String, confirmed: Boolean = false): Boolean {
        val prompt = text.trim()
        val image = pendingImage.value
        if (_loading.value || (prompt.isEmpty() && image == null)) return false
        if (image != null && !confirmed) {
            awaitingImageConfirm.value = true
            return false
        }
        awaitingImageConfirm.value = false
        pendingImage.value = null
        _error.value = null

        val shown = prompt.ifEmpty { container.app.getString(R.string.default_image_prompt) }
        val modeNow = _mode.value
        val history = _messages.value.map { ChatTurn(it.role, it.text) }
        _messages.value = _messages.value + UiMessage(localId--, "user", shown, hasImage = image != null)
        _loading.value = true

        job = scope.launch {
            try {
                val convId = ensureConversation(shown, modeNow)
                if (convId != null) container.chatRepository.addMessage(convId, "user", shown, image != null)
                val answer = container.aiRepository.ask(modeNow, history, shown, image)
                val savedId = if (convId != null) container.chatRepository.addMessage(convId, "model", answer) else localId--
                _messages.value = _messages.value + UiMessage(savedId, "model", answer)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e
            } finally {
                _loading.value = false
            }
        }
        return true
    }

    /** Memulai percakapan baru dari serah-terima layar lain (Scan atau Target nilai). */
    fun startFrom(pending: PendingChat) {
        newConversation()
        sourceOverride = pending.source
        pending.mode?.let { setMode(it) }
        pendingImage.value = pending.image
        send(pending.prompt, confirmed = true)
    }

    private suspend fun ensureConversation(firstText: String, mode: AnswerMode): Long? {
        conversationId?.let { return it }
        if (!container.settings.snapshot().saveHistory) return null
        val title = firstText.lineSequence().firstOrNull().orEmpty().take(48)
        val id = container.chatRepository.create(title, sourceOverride ?: source, mode)
        sourceOverride = null
        conversationId = id
        return id
    }

    suspend fun open(id: Long) {
        if (conversationId == id) return
        job?.cancel()
        _loading.value = false
        _error.value = null
        clearImage()
        val loaded = container.chatRepository.load(id) ?: return
        conversationId = id
        modeTouched = true
        _mode.value = AnswerMode.from(loaded.conversation.mode)
        _messages.value = loaded.messages.map { UiMessage(it.id, it.role, it.text, it.hasImage) }
    }

    fun newConversation() {
        job?.cancel()
        _loading.value = false
        _error.value = null
        clearImage()
        _messages.value = emptyList()
        conversationId = null
        sourceOverride = null
        input = ""
    }

    fun deleteCurrent() {
        val id = conversationId
        newConversation()
        if (id != null) scope.launch { container.chatRepository.delete(id) }
    }

    fun close() {
        job?.cancel()
    }
}
