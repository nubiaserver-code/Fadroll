package com.fadrol.ai.ai

import android.content.Context
import android.graphics.Bitmap
import com.fadrol.ai.network.GeminiRestService
import com.fadrol.ai.settings.AppSettings
import com.fadrol.ai.settings.SettingsStore
import com.google.firebase.FirebaseApp
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Satu pintu ke layanan AI. AI Chat, panel mengambang, Scan, dan Target nilai semuanya lewat sini,
 * jadi pengaturan sumber AI dan model selalu konsisten.
 */
class AiRepository(
    private val context: Context,
    private val settings: SettingsStore,
    private val verified: MutableStateFlow<Boolean>,
) {

    suspend fun status(): AiStatus {
        val s = settings.snapshot()
        return when (s.aiSource) {
            AiSource.FIREBASE -> {
                val ok = FirebaseApp.getApps(context).isNotEmpty()
                AiStatus(AiSource.FIREBASE, ok, if (ok) null else AiErrorKind.FIREBASE_NOT_CONFIGURED)
            }

            AiSource.OWN_KEY -> {
                val ok = settings.apiKey().isNotBlank()
                AiStatus(AiSource.OWN_KEY, ok, if (ok) null else AiErrorKind.NO_API_KEY)
            }
        }
    }

    suspend fun ask(mode: AnswerMode, history: List<ChatTurn>, prompt: String, image: Bitmap?): String {
        val s = settings.snapshot()
        var past = normalize(history)
        var finalPrompt = prompt
        // Giliran user terakhir yang belum terjawab (mis. karena error) digabung ke pertanyaan baru.
        if (past.isNotEmpty() && past.last().role == "user") {
            finalPrompt = past.last().text + "\n\n" + prompt
            past = past.dropLast(1)
        }
        val system = Prompts.system(mode, isEnglish(s.language))
        val text = service(s).generate(system, past, finalPrompt, image, json = false)
        verified.value = true
        return text
    }

    /** Untuk keluaran JSON terstruktur (penilaian latihan Target nilai). */
    suspend fun askJson(system: String, prompt: String): String {
        val s = settings.snapshot()
        val text = service(s).generate(system, emptyList(), prompt, null, json = true)
        verified.value = true
        return text
    }

    private suspend fun service(s: AppSettings): AiService {
        val model = s.modelName.ifBlank { AppSettings.DEFAULT_MODEL }
        return when (s.aiSource) {
            AiSource.FIREBASE -> FirebaseGeminiService(context, model)
            AiSource.OWN_KEY -> {
                val key = settings.apiKey()
                if (key.isBlank()) throw AiException(AiErrorKind.NO_API_KEY)
                GeminiRestService(key, model)
            }
        }
    }

    private fun isEnglish(language: String): Boolean =
        language == "en" || (language == "system" && Locale.getDefault().language == "en")

    /** Gemini mewajibkan giliran bergantian user/model dan diawali user. */
    private fun normalize(history: List<ChatTurn>): List<ChatTurn> {
        val out = ArrayList<ChatTurn>()
        for (turn in history.takeLast(14)) {
            val text = turn.text.take(4000)
            if (out.isNotEmpty() && out.last().role == turn.role) {
                out[out.lastIndex] = out.last().copy(text = out.last().text + "\n\n" + text)
            } else {
                out.add(ChatTurn(turn.role, text))
            }
        }
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        return out
    }
}
