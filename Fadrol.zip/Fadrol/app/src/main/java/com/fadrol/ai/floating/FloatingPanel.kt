@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.floating

import android.content.Context
import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.fadrol.ai.AppContainer
import com.fadrol.ai.PendingChat
import com.fadrol.ai.R
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.chat.ChatController
import com.fadrol.ai.settings.AppSettings
import com.fadrol.ai.targetscore.TargetScoreContent
import com.fadrol.ai.targetscore.TargetScoreState
import com.fadrol.ai.ui.components.ChatBody
import com.fadrol.ai.ui.components.ExpandIcon
import com.fadrol.ai.ui.components.FadrolLogo
import com.fadrol.ai.ui.components.ScanFlow
import com.fadrol.ai.ui.components.ScanFlowState
import com.fadrol.ai.ui.theme.FadrolTheme
import java.util.Locale
import kotlinx.coroutines.CoroutineScope

enum class PanelView { CHAT, TARGET, SCAN }

enum class PanelSize { MINI, NORMAL, EXPANDED }

/** State panel mengambang. Dipegang FloatingService sehingga percakapan bertahan walau panel ditutup. */
class PanelUi(val container: AppContainer, scope: CoroutineScope) {
    val chat = ChatController(container, scope, "floating")
    val target = TargetScoreState(container, scope)
    val scan = ScanFlowState(container, scope)

    var view by mutableStateOf(PanelView.CHAT)
    var size by mutableStateOf(PanelSize.NORMAL)
    var menuOpen by mutableStateOf(false)

    /** Id string resource untuk pesan singkat (mis. tangkap layar gagal). */
    var notice by mutableStateOf<Int?>(null)
}

class PanelActions(
    val onClose: () -> Unit,
    val onPickGallery: () -> Unit,
    val onPickCamera: () -> Unit,
    val onReadScreen: () -> Unit,
    val onHideIcon: () -> Unit,
    val onStopService: () -> Unit,
)

private fun Context.withLanguage(language: String): Context {
    if (language == "system") return this
    val config = Configuration(resources.configuration)
    config.setLocale(Locale(language))
    return createConfigurationContext(config)
}

@Composable
fun FloatingPanelHost(
    ui: PanelUi,
    actions: PanelActions,
    initialSettings: AppSettings,
) {
    val settings by ui.container.settings.flow.collectAsState(initial = initialSettings)
    val base = LocalContext.current
    // Context service tidak ikut pengaturan bahasa per-aplikasi pada Android 12 ke bawah, jadi diterapkan manual.
    val localized = remember(base, settings.language) { base.withLanguage(settings.language) }
    CompositionLocalProvider(LocalContext provides localized) {
        FadrolTheme(settings.theme) {
            PanelContent(ui, actions)
        }
    }
}

@Composable
private fun PanelContent(ui: PanelUi, actions: PanelActions) {
    val colors = MaterialTheme.colorScheme
    val mini = ui.size == PanelSize.MINI
    Surface(
        color = colors.background,
        contentColor = colors.onBackground,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, colors.outlineVariant),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (mini) Modifier else Modifier.fillMaxHeight()),
    ) {
        Column(if (mini) Modifier.fillMaxWidth() else Modifier.fillMaxSize()) {
            PanelHeader(ui, actions)
            if (ui.menuOpen) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    TextButton(onClick = {
                        ui.menuOpen = false
                        actions.onHideIcon()
                    }) { Text(stringResource(R.string.panel_hide_icon)) }
                    TextButton(onClick = {
                        ui.menuOpen = false
                        actions.onStopService()
                    }) { Text(stringResource(R.string.panel_stop)) }
                }
            }
            if (!mini) {
                when (ui.view) {
                    PanelView.CHAT -> ChatBody(
                        controller = ui.chat,
                        onPickGallery = actions.onPickGallery,
                        onPickCamera = actions.onPickCamera,
                        modifier = Modifier.weight(1f),
                        compact = true,
                        onReadScreen = actions.onReadScreen,
                        onTargetScore = { ui.view = PanelView.TARGET },
                        notice = ui.notice,
                        onDismissNotice = { ui.notice = null },
                    )

                    PanelView.TARGET -> TargetScoreContent(
                        state = ui.target,
                        onDiscuss = { prompt ->
                            ui.chat.startFrom(PendingChat(prompt, null, AnswerMode.FULL, "target"))
                            ui.view = PanelView.CHAT
                        },
                        onBackToChat = { ui.view = PanelView.CHAT },
                        modifier = Modifier.weight(1f),
                        onScanQuestions = null,
                    )

                    PanelView.SCAN -> ScanFlow(
                        state = ui.scan,
                        onSend = { prompt, image ->
                            ui.chat.startFrom(PendingChat(prompt, image, null, "scan"))
                            ui.scan.clear()
                            ui.view = PanelView.CHAT
                            ui.size = PanelSize.NORMAL
                        },
                        onClose = {
                            ui.scan.clear()
                            ui.view = PanelView.CHAT
                            ui.size = PanelSize.NORMAL
                        },
                        modifier = Modifier.weight(1f),
                        onUseForTarget = {
                            ui.container.lastOcrText.value = ui.scan.ocrText
                            ui.target.practiceMode = true
                            ui.target.useLastOcr()
                            ui.view = PanelView.TARGET
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun PanelHeader(ui: PanelUi, actions: PanelActions) {
    val mini = ui.size == PanelSize.MINI
    val expanded = ui.size == PanelSize.EXPANDED
    val tint = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FadrolLogo(28.dp)
        Spacer(Modifier.width(8.dp))
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.weight(1f),
        )
        IconButton(
            onClick = { ui.size = if (mini) PanelSize.NORMAL else PanelSize.MINI },
            modifier = Modifier.size(40.dp),
        ) {
            Icon(
                imageVector = if (mini) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp,
                contentDescription = stringResource(if (mini) R.string.panel_restore else R.string.panel_minimize),
                tint = tint,
            )
        }
        IconButton(
            onClick = { ui.size = if (expanded) PanelSize.NORMAL else PanelSize.EXPANDED },
            modifier = Modifier.size(40.dp),
        ) {
            ExpandIcon(isExpanded = expanded, tint = tint)
        }
        IconButton(onClick = { ui.menuOpen = !ui.menuOpen }, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.panel_menu), tint = tint)
        }
        IconButton(onClick = actions.onClose, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.panel_close), tint = tint)
        }
    }
}
