package com.fadrol.ai.settings

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.fadrol.ai.ai.AiSource
import com.fadrol.ai.ai.AnswerMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, LIGHT, DARK }

fun ThemeMode.toNightMode(): Int = when (this) {
    ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
    ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
    ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
}

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    /** "system", "id", atau "en". */
    val language: String = "system",
    val answerMode: AnswerMode = AnswerMode.FULL,
    val iconSizeDp: Int = 56,
    val snapToEdge: Boolean = true,
    val iconLeft: Boolean = false,
    /** Posisi vertikal terakhir ikon (px). -1 berarti belum pernah digeser. */
    val iconY: Int = -1,
    val saveHistory: Boolean = true,
    val aiSource: AiSource = AiSource.FIREBASE,
    val modelName: String = DEFAULT_MODEL,
    /** API key Gemini milik pengguna, terenkripsi dengan Android Keystore. Tidak pernah ada di dalam APK. */
    val apiKeyEncrypted: String = "",
) {
    companion object {
        const val DEFAULT_MODEL = "gemini-3.5-flash"
    }
}

private val Context.fadrolDataStore by preferencesDataStore(name = "fadrol_settings")

private inline fun <reified T : Enum<T>> enumOrDefault(name: String?, default: T): T =
    name?.let { n -> enumValues<T>().firstOrNull { it.name == n } } ?: default

class SettingsStore(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val LANGUAGE = stringPreferencesKey("language")
        val ANSWER_MODE = stringPreferencesKey("answer_mode")
        val ICON_SIZE = intPreferencesKey("icon_size_dp")
        val SNAP = booleanPreferencesKey("snap_to_edge")
        val ICON_LEFT = booleanPreferencesKey("icon_left")
        val ICON_Y = intPreferencesKey("icon_y")
        val SAVE_HISTORY = booleanPreferencesKey("save_history")
        val AI_SOURCE = stringPreferencesKey("ai_source")
        val MODEL = stringPreferencesKey("model_name")
        val API_KEY = stringPreferencesKey("api_key_enc")
    }

    val flow: Flow<AppSettings> = context.fadrolDataStore.data.map { p ->
        AppSettings(
            theme = enumOrDefault(p[Keys.THEME], ThemeMode.SYSTEM),
            language = p[Keys.LANGUAGE] ?: "system",
            answerMode = AnswerMode.from(p[Keys.ANSWER_MODE]),
            iconSizeDp = p[Keys.ICON_SIZE] ?: 56,
            snapToEdge = p[Keys.SNAP] ?: true,
            iconLeft = p[Keys.ICON_LEFT] ?: false,
            iconY = p[Keys.ICON_Y] ?: -1,
            saveHistory = p[Keys.SAVE_HISTORY] ?: true,
            aiSource = enumOrDefault(p[Keys.AI_SOURCE], AiSource.FIREBASE),
            modelName = p[Keys.MODEL] ?: AppSettings.DEFAULT_MODEL,
            apiKeyEncrypted = p[Keys.API_KEY] ?: "",
        )
    }

    suspend fun snapshot(): AppSettings = flow.first()

    suspend fun setTheme(value: ThemeMode) {
        context.fadrolDataStore.edit { it[Keys.THEME] = value.name }
    }

    suspend fun setLanguage(value: String) {
        context.fadrolDataStore.edit { it[Keys.LANGUAGE] = value }
    }

    suspend fun setAnswerMode(value: AnswerMode) {
        context.fadrolDataStore.edit { it[Keys.ANSWER_MODE] = value.key }
    }

    suspend fun setIconSize(dp: Int) {
        context.fadrolDataStore.edit { it[Keys.ICON_SIZE] = dp.coerceIn(40, 88) }
    }

    suspend fun setSnapToEdge(value: Boolean) {
        context.fadrolDataStore.edit { it[Keys.SNAP] = value }
    }

    suspend fun setIconPosition(left: Boolean, y: Int) {
        context.fadrolDataStore.edit {
            it[Keys.ICON_LEFT] = left
            it[Keys.ICON_Y] = y
        }
    }

    suspend fun setIconSide(left: Boolean) {
        context.fadrolDataStore.edit { it[Keys.ICON_LEFT] = left }
    }

    suspend fun resetIconPosition() {
        context.fadrolDataStore.edit {
            it[Keys.ICON_LEFT] = false
            it[Keys.ICON_Y] = -1
        }
    }

    suspend fun setSaveHistory(value: Boolean) {
        context.fadrolDataStore.edit { it[Keys.SAVE_HISTORY] = value }
    }

    suspend fun setAiSource(value: AiSource) {
        context.fadrolDataStore.edit { it[Keys.AI_SOURCE] = value.name }
    }

    suspend fun setModelName(value: String) {
        context.fadrolDataStore.edit { it[Keys.MODEL] = value.trim().ifEmpty { AppSettings.DEFAULT_MODEL } }
    }

    suspend fun setApiKey(plain: String) {
        val stored = if (plain.isBlank()) "" else SecretBox.encrypt(plain.trim())
        context.fadrolDataStore.edit { it[Keys.API_KEY] = stored }
    }

    suspend fun apiKey(): String {
        val enc = snapshot().apiKeyEncrypted
        return if (enc.isEmpty()) "" else SecretBox.decrypt(enc).orEmpty()
    }
}
