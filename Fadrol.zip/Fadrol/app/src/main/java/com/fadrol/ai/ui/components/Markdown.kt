package com.fadrol.ai.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

private val HEADING = Regex("^\\s*#{1,6}\\s+(.*)$")
private val BULLET = Regex("^\\s*[-*\u2022]\\s+(.*)$")

/**
 * Pemformat Markdown ringan untuk jawaban AI: judul, butir daftar, **tebal**, dan `kode`.
 * Sengaja tidak menafsirkan *miring* agar tanda kali pada rumus (3 * 4) tidak rusak.
 */
fun markdownToAnnotated(text: String, codeBackground: Color): AnnotatedString = buildAnnotatedString {
    val lines = text.lines()
    lines.forEachIndexed { index, raw ->
        val heading = HEADING.matchEntire(raw)
        val bullet = BULLET.matchEntire(raw)
        when {
            heading != null -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                appendInline(heading.groupValues[1], codeBackground)
            }

            bullet != null -> {
                append("\u2022 ")
                appendInline(bullet.groupValues[1], codeBackground)
            }

            else -> appendInline(raw, codeBackground)
        }
        if (index < lines.lastIndex) append("\n")
    }
}

private fun AnnotatedString.Builder.appendInline(s: String, codeBackground: Color) {
    var i = 0
    while (i < s.length) {
        if (s.startsWith("**", i)) {
            val end = s.indexOf("**", i + 2)
            if (end > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, end)) }
                i = end + 2
                continue
            }
        } else if (s[i] == '`') {
            val end = s.indexOf('`', i + 1)
            if (end > i + 1) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBackground)) {
                    append(s.substring(i + 1, end))
                }
                i = end + 1
                continue
            }
        }
        append(s[i])
        i++
    }
}
