@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.fadrol.ai.AppContainer
import com.fadrol.ai.PendingChat
import com.fadrol.ai.R
import com.fadrol.ai.appContainer
import com.fadrol.ai.ui.components.ImagePickers
import com.fadrol.ai.ui.components.ScanFlow
import com.fadrol.ai.ui.components.ScanFlowState
import com.fadrol.ai.ui.components.rememberImagePickers

class ScanViewModel(container: AppContainer) : ViewModel() {
    val flow = ScanFlowState(container, viewModelScope)
}

/** Unggah/foto gambar, pangkas, baca teks (OCR), periksa hasilnya, lalu kirim ke AI setelah konfirmasi. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanScreen(
    onBack: () -> Unit,
    onSentToChat: () -> Unit,
    onUseForTarget: () -> Unit,
) {
    val context = LocalContext.current
    val container = remember { context.appContainer() }
    val vm: ScanViewModel = viewModel(factory = viewModelFactory { initializer { ScanViewModel(container) } })
    val flow = vm.flow
    val pickers = rememberImagePickers { bitmap -> flow.start(bitmap) }

    BackHandler(enabled = flow.hasImage) { flow.clear() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.scan_title)) },
                navigationIcon = {
                    IconButton(onClick = { if (flow.hasImage) flow.clear() else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
            )
        },
    ) { padding ->
        Box(
            Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .fillMaxSize(),
        ) {
            if (!flow.hasImage) {
                PickSource(pickers)
            } else {
                ScanFlow(
                    state = flow,
                    onSend = { prompt, image ->
                        container.pendingChat.value = PendingChat(prompt, image, null, "scan")
                        flow.clear()
                        onSentToChat()
                    },
                    onClose = { flow.clear() },
                    modifier = Modifier.fillMaxSize(),
                    onUseForTarget = {
                        container.lastOcrText.value = flow.ocrText
                        onUseForTarget()
                    },
                )
            }
        }
    }
}

@Composable
private fun PickSource(pickers: ImagePickers) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.scan_pick_title), style = MaterialTheme.typography.titleLarge)
        Text(
            text = stringResource(R.string.scan_pick_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = pickers.gallery, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.scan_gallery))
        }
        FilledTonalButton(onClick = pickers.camera, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.scan_camera))
        }
    }
}
