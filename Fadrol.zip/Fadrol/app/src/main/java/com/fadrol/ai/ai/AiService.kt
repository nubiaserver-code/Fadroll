package com.fadrol.ai.ai

import android.graphics.Bitmap

/** Kontrak layanan AI. Ada dua implementasi: Firebase AI Logic dan REST dengan API key milik pengguna. */
interface AiService {
    suspend fun generate(
        system: String,
        history: List<ChatTurn>,
        prompt: String,
        image: Bitmap?,
        json: Boolean = false,
    ): String
}
