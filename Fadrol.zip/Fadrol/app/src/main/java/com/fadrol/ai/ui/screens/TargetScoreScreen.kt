@file:OptIn(ExperimentalMaterial3Api::class)

package com.fadrol.ai.ui.screens

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.fadrol.ai.AppContainer
import com.fadrol.ai.PendingChat
import com.fadrol.ai.R
import com.fadrol.ai.ai.AnswerMode
import com.fadrol.ai.appContainer
import com.fadrol.ai.targetscore.TargetScoreContent
import com.fadrol.ai.targetscore.TargetScoreState

class TargetScoreViewModel(container: AppContainer) : ViewModel() {
    val state = TargetScoreState(container, viewModelScope)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TargetScoreScreen(
    onBack: () -> Unit,
    onOpenChat: () -> Unit,
    onScan: () -> Unit,
) {
    val context = LocalContext.current
    val container = remember { context.appContainer() }
    val vm: TargetScoreViewModel = viewModel(factory = viewModelFactory { initializer { TargetScoreViewModel(container) } })

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.ts_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
            )
        },
    ) { padding ->
        TargetScoreContent(
            state = vm.state,
            onDiscuss = { prompt ->
                container.pendingChat.value = PendingChat(prompt, null, AnswerMode.FULL, "target")
                onOpenChat()
            },
            onBackToChat = onOpenChat,
            modifier = Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding(),
            onScanQuestions = onScan,
        )
    }
}
