package com.fadrol.ai.ai

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

/**
 * Build release: App Check memakai Play Integrity.
 * Catatan: APK yang dipasang manual (sideload) tidak lolos Play Integrity; untuk uji coba pakai build debug
 * (token debug) atau pilih "API key sendiri" di Pengaturan.
 */
object AppCheckInstaller {

    fun install(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) return
            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance())
        } catch (e: Throwable) {
            // Firebase belum dikonfigurasi; AI lewat API key sendiri tetap jalan.
        }
    }

    fun warmUp() = Unit

    fun debugToken(context: Context): String? = null
}
