package com.fadrol.ai.targetscore

import com.fadrol.ai.targetscore.AnswerState.CORRECT
import com.fadrol.ai.targetscore.AnswerState.UNANSWERED
import com.fadrol.ai.targetscore.AnswerState.WRONG
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Menguji perhitungan Target nilai. Nilai harapan disusun dari contoh pada spesifikasi dan dicocokkan
 * dengan uji brute force rancangan algoritma (lihat docs/TEST_REPORT.md). Jalankan: ./gradlew testDebugUnitTest
 */
class TargetScoreCalculatorTest {

    private val delta = 1e-9

    private fun config(
        target: Double,
        weights: List<Double>,
        initial: Double = 0.0,
        penalty: Double = 0.0,
    ) = ScoreConfig(target, weights, initial, penalty)

    private fun equal(count: Int) = TargetScoreCalculator.equalWeights(count)

    private fun states(correct: Int, wrong: Int, total: Int): List<AnswerState> =
        List(total) { i ->
            if (i < correct) CORRECT else if (i < correct + wrong) WRONG else UNANSWERED
        }

    // ---- contoh dari spesifikasi ----

    @Test
    fun twentyEqualQuestionsTarget80NeedsSixteenCorrectAndAllowsFourWrong() {
        val req = TargetScoreCalculator.requirement(config(80.0, equal(20)))
        assertEquals(16, req.minCorrect)
        assertEquals(16, req.safeCorrect)
        assertEquals(4, 20 - req.minCorrect)
        assertFalse(req.alreadyMet)
    }

    @Test
    fun simulationTableFromSpecification() {
        val c = config(80.0, equal(20))
        val table = listOf(20 to 0 to 100.0, 18 to 2 to 90.0, 16 to 4 to 80.0, 14 to 6 to 70.0, 12 to 8 to 60.0)
        for ((counts, expected) in table) {
            val (correct, wrong) = counts
            val result = TargetScoreCalculator.simulate(c, states(correct, wrong, 20))
            assertEquals(expected, result.score, delta)
            assertEquals(correct, result.correct)
            assertEquals(wrong, result.wrong)
        }
    }

    @Test
    fun unansweredQuestionsScoreZeroWithoutPenalty() {
        val result = TargetScoreCalculator.simulate(config(80.0, equal(20), penalty = 0.5), states(10, 0, 20))
        assertEquals(50.0, result.score, delta)
        assertEquals(10, result.unanswered)
    }

    // ---- bobot berbeda ----

    @Test
    fun differentWeightsUseTotalWeight() {
        val c = config(70.0, listOf(1.0, 2.0, 3.0, 4.0))
        val req = TargetScoreCalculator.requirement(c)
        assertEquals(7.0, req.neededWeight, delta)
        assertEquals(2, req.minCorrect) // 4 + 3
        assertEquals(4, req.safeCorrect) // soal teringan harus ikut: 1 + 2 + 3 + 4
        val sim = TargetScoreCalculator.simulate(c, listOf(UNANSWERED, UNANSWERED, CORRECT, CORRECT))
        assertEquals(70.0, sim.score, delta)
    }

    @Test
    fun mixedWeightsExample() {
        val c = config(75.0, listOf(2.0, 2.0, 3.0, 3.0, 5.0, 5.0))
        val req = TargetScoreCalculator.requirement(c)
        assertEquals(4, req.minCorrect)
        assertEquals(5, req.safeCorrect)
    }

    // ---- penalti dan nilai awal ----

    @Test
    fun wrongPenaltyReducesScoreAndRaisesRequirementWhenRestIsAnsweredWrong() {
        val c = config(80.0, equal(10), penalty = 0.25)
        val req = TargetScoreCalculator.requirement(c)
        assertEquals(8, req.minCorrect)
        assertEquals(9, req.minCorrectIfRestWrong)
        assertEquals(75.0, TargetScoreCalculator.simulate(c, states(8, 2, 10)).score, delta)
        assertEquals(87.5, TargetScoreCalculator.simulate(c, states(9, 1, 10)).score, delta)
    }

    @Test
    fun startingScoreSharesRemainingPoints() {
        val c = config(80.0, equal(10), initial = 60.0)
        assertEquals(5, TargetScoreCalculator.requirement(c).minCorrect)
        assertEquals(80.0, TargetScoreCalculator.simulate(c, states(5, 0, 10)).score, delta)
        assertEquals(60.0, TargetScoreCalculator.simulate(c, states(0, 0, 10)).score, delta)
        assertEquals(100.0, TargetScoreCalculator.simulate(c, states(10, 0, 10)).score, delta)
    }

    @Test
    fun targetBelowStartingScoreIsAlreadyMet() {
        val req = TargetScoreCalculator.requirement(config(50.0, equal(10), initial = 60.0))
        assertTrue(req.alreadyMet)
        assertEquals(0, req.minCorrect)
    }

    @Test
    fun penaltyWithStartingScoreRegression() {
        // Skor bisa turun di bawah nilai awal karena penalti, jadi kebutuhan tidak boleh dipotong di nol.
        val c = config(10.0, listOf(1.0, 4.0, 2.0, 1.0, 3.0, 3.0, 1.0), initial = 20.0, penalty = 0.25)
        val req = TargetScoreCalculator.requirement(c)
        assertEquals(0, req.minCorrect)
        assertEquals(1, req.minCorrectIfRestWrong)
        assertEquals(2, req.safeCorrectIfRestWrong)
    }

    @Test
    fun targetZeroIsAlwaysMetEvenWithPenalty() {
        val c = config(0.0, listOf(4.0, 4.0, 1.0, 0.5, 1.0, 1.0, 1.0, 2.0), penalty = 0.5)
        val req = TargetScoreCalculator.requirement(c)
        assertEquals(0, req.minCorrectIfRestWrong)
        assertEquals(0, req.safeCorrectIfRestWrong)
        assertEquals(0.0, TargetScoreCalculator.simulate(c, List(8) { WRONG }).score, delta) // dibatasi minimal 0
    }

    // ---- target tidak tercapai dan sisa kebutuhan ----

    @Test
    fun unreachableTargetIsDetectedWithReason() {
        val c = config(90.0, equal(10))
        val status = TargetScoreCalculator.status(c, listOf(WRONG, WRONG) + List(8) { UNANSWERED })
        assertFalse(status.reachable)
        assertEquals(80.0, status.bestPossibleScore, delta)
        assertNull(status.moreCorrectNeeded)
        assertEquals(8, status.unansweredLeft)
    }

    @Test
    fun remainingCorrectAnswersNeeded() {
        val c = config(80.0, equal(10))
        val status = TargetScoreCalculator.status(c, listOf(CORRECT, CORRECT, CORRECT, WRONG) + List(6) { UNANSWERED })
        assertTrue(status.reachable)
        assertEquals(5, status.moreCorrectNeeded)
        assertEquals(6, status.unansweredLeft)
        assertEquals(90.0, status.bestPossibleScore, delta)
        assertEquals(0, TargetScoreCalculator.status(c, List(9) { CORRECT } + UNANSWERED).moreCorrectNeeded)
    }

    // ---- batas dan galat pembulatan ----

    @Test
    fun boundaryTargets() {
        assertEquals(0, TargetScoreCalculator.requirement(config(0.0, equal(7))).minCorrect)
        assertEquals(7, TargetScoreCalculator.requirement(config(100.0, equal(7))).minCorrect)
        assertEquals(6, TargetScoreCalculator.requirement(config(85.0, equal(7))).minCorrect) // 5,95 dibulatkan ke atas
        assertEquals(7, TargetScoreCalculator.requirement(config(70.0, equal(10))).minCorrect) // bukan 8 karena galat floating point
        assertTrue(TargetScoreCalculator.requirement(config(100.0, equal(1), initial = 100.0)).alreadyMet)
    }

    @Test
    fun progressAndGapAgainstTarget() {
        val sim = TargetScoreCalculator.simulate(config(80.0, equal(20)), states(12, 8, 20))
        assertEquals(60.0, sim.score, delta)
        assertEquals(0.75, sim.targetProgress, delta)
        assertEquals(-20.0, sim.gap, delta)
    }

    // ---- penguraian bobot ----

    @Test
    fun parseWeights() {
        assertEquals(listOf(1.0, 2.5, 3.0), TargetScoreCalculator.parseWeights("1, 2.5  3"))
        assertEquals(listOf(2.0, 2.0), TargetScoreCalculator.parseWeights("2;2"))
        assertNotNull(TargetScoreCalculator.parseWeights("5\n5"))
        assertNull(TargetScoreCalculator.parseWeights(""))
        assertNull(TargetScoreCalculator.parseWeights("1 0 3"))
        assertNull(TargetScoreCalculator.parseWeights("1 -2"))
        assertNull(TargetScoreCalculator.parseWeights("1 abc"))
        assertNull(TargetScoreCalculator.parseWeights(List(201) { "1" }.joinToString(" ")))
    }

    @Test
    fun formatNumberDropsTrailingZeros() {
        assertEquals("80", TargetScoreCalculator.formatNumber(80.0))
        assertEquals("80", TargetScoreCalculator.formatNumber(79.999999999))
    }
}
