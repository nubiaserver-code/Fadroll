# Aturan R8 untuk build release. Library (Room, Firebase, ML Kit, Compose) membawa consumer rules sendiri.
# Jika R8 melaporkan "Missing class", tambahkan -dontwarn untuk kelas tersebut di sini.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
