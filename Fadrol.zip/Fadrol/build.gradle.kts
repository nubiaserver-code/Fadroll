// Versi plugin dipin ke kombinasi yang konsisten (AGP 8.13.2 + Gradle 8.13 + Kotlin 2.2.21).
// Jangan naikkan ke AGP 9 tanpa migrasi (built-in Kotlin berubah). Lihat README.md.
plugins {
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false
    id("com.google.devtools.ksp") version "2.2.21-2.0.4" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}
