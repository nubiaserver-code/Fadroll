# Fadrol

Asisten belajar Android dengan ikon mengambang di atas aplikasi lain. Fadrol membantu menjawab soal, menjelaskan materi, membaca teks dari gambar dan screenshot (OCR), dan menghitung serta menyimulasikan skor lewat fitur **Target nilai**.

- Package: `com.fadrol.ai` · Developer: Fadrol · Bahasa: Indonesia (utama) dan Inggris
- Kotlin, Jetpack Compose, Room, DataStore, MediaProjection, ML Kit OCR, Gemini lewat Firebase AI Logic

## Status jujur

Proyek ini lengkap (kode, resource, Gradle, dokumentasi), tetapi **belum ada APK yang terbukti berhasil dibangun dan belum dijalankan di perangkat**. Lingkungan tempat proyek ini ditulis tidak punya Android SDK, Gradle, kompiler Kotlin, maupun akses internet. Apa yang sudah dan belum diperiksa ada di [docs/TEST_REPORT.md](docs/TEST_REPORT.md). Anggap semua fitur sebagai "terimplementasi, belum teruji" sampai kamu menjalankan checklist pengujian di dokumen itu.

## Cara mendapatkan APK

### A. Android Studio (paling mudah)

1. Pasang Android Studio versi terbaru, lalu **Open** folder `Fadrol`.
2. Biarkan Gradle sync selesai (akan mengunduh Gradle 8.13, SDK Platform 36, dan dependency). Jika diminta menaikkan Android Gradle Plugin ke versi 9, **tolak dulu**; proyek ini dipin ke AGP 8.13.2.
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Hasilnya: `app/build/outputs/apk/debug/app-debug.apk`. Ganti nama menjadi `Fadrol.apk` bila perlu.

### B. Baris perintah

```bash
cd Fadrol
gradle wrapper --gradle-version 8.13     # sekali saja, membuat gradlew
./gradlew testDebugUnitTest              # unit test perhitungan Target nilai
./gradlew assembleDebug                  # APK debug
```

Butuh JDK 17 atau lebih baru dan Android SDK (`ANDROID_HOME`).

### C. Tanpa komputer berisi Android Studio: GitHub Actions

Unggah folder ini ke repositori GitHub, buka tab **Actions**, jalankan **Build APK**. Berkas `Fadrol.apk` (debug) muncul sebagai artifact. Workflow ada di `.github/workflows/build-apk.yml`. Belum pernah dijalankan.

### APK release

Tanpa `keystore.properties`, build release ditandatangani kunci debug (cukup untuk uji coba, bukan untuk Play Store). Untuk rilis sungguhan:

```bash
keytool -genkeypair -v -keystore fadrol.jks -alias fadrol -keyalg RSA -keysize 2048 -validity 10000
```

lalu buat `keystore.properties` di folder root:

```
storeFile=fadrol.jks
storePassword=...
keyAlias=fadrol
keyPassword=...
```

dan jalankan `./gradlew assembleRelease`. Release memakai R8 (minify); jika R8 melaporkan `Missing class`, tambahkan `-dontwarn` di `app/proguard-rules.pro`.

## Menghidupkan AI

Ada dua jalur. Detail lengkap di [docs/AI_SETUP.md](docs/AI_SETUP.md).

1. **API key sendiri (tercepat untuk mencoba).** Ambil key dari Google AI Studio, buka Fadrol > Pengaturan > AI > *API key sendiri*, tempel key, Simpan, lalu **Tes koneksi AI**. Key disimpan terenkripsi (Android Keystore) di perangkat, tidak ada di dalam APK.
2. **Firebase AI Logic (jalur utama untuk produksi).** Buat proyek Firebase, daftarkan app `com.fadrol.ai`, taruh `google-services.json` di `app/`, aktifkan Gemini Developer API di konsol Firebase AI Logic, dan siapkan App Check. Tanpa `google-services.json` proyek tetap bisa dibangun; aplikasi akan menampilkan pesan konfigurasi.

Fadrol tidak menyatakan AI aktif sebelum ada satu jawaban sungguhan yang diterima. Layar utama menampilkan status "belum dikonfigurasi" atau "belum diuji".

## Cara kerja fitur

| Fitur | Ringkasan |
|---|---|
| Ikon mengambang | Foreground service + `WindowManager` (`TYPE_APPLICATION_OVERLAY`), izin `SYSTEM_ALERT_WINDOW`. Bisa digeser, menempel ke sisi kiri/kanan, ukuran diatur, disembunyikan/ditampilkan, dihentikan dari aplikasi, notifikasi, atau menu panel. Panduan izin muncul bila izin belum diberikan. |
| Panel AI | Compose di dalam jendela overlay. Chat, galeri, kamera, baca layar, Target nilai, salin jawaban, minimalkan, perbesar, tutup. Menempel di atas layar agar keyboard tidak menutupinya; sentuhan di luar panel diteruskan ke aplikasi di bawahnya. |
| Mode jawaban | Singkat, Lengkap, Belajar. Prompt sistem melarang mengarang dan meminta pemeriksaan ulang hitungan. |
| Baca soal di layar | `MediaProjection` dengan dialog persetujuan sistem. Satu frame saja, lalu semua resource dilepas. Ikon dan panel disembunyikan sesaat sebelum frame diambil. Layar hitam (aplikasi memblokir screenshot) terdeteksi dan diberi peringatan. Gambar hanya di memori. |
| Scan, OCR | Galeri (Photo Picker), kamera, pangkas, putar, ML Kit OCR (Latin, offline), hasil OCR bisa diedit, peringatan buram/kosong, konfirmasi sebelum kirim. Untuk rumus, tabel, diagram tersedia **Analisis gambar** (model multimodal), bukan hanya OCR. |
| Target nilai | Target 0–100, jumlah soal, bobot sama atau berbeda, nilai awal, penalti salah, mode Simulasi dan Latihan. Seluruh skor dihitung program (`targetscore/TargetScoreCalculator.kt`), bukan model bahasa. Mode Latihan: AI menilai tiap nomor dan simulasi terisi otomatis. |
| Riwayat | Room: judul, pesan, waktu, mode, pengaturan simulasi. Cari, buka, hapus satu atau semua. Screenshot tidak disimpan. |
| Pengaturan | Ikon (ukuran, sisi, tempel, reset), tema (sistem/terang/gelap), bahasa, sumber AI, model, mode bawaan, riwayat, privasi. |

### Rumus Target nilai

```
skor = nilaiAwal + (bobotBenar - penalti x bobotSalah) / totalBobot x (100 - nilaiAwal)   (dibatasi 0..100)
```

Dengan nilai awal 0, bobot sama, dan tanpa penalti ini menjadi `benar / jumlahSoal x 100`. Contoh: 20 soal, target 80 butuh 16 benar (salah maksimal 4). Bila bobot berbeda, kebutuhan ditampilkan sebagai "paling sedikit N benar" (soal terberat) dan "N benar pasti cukup" (soal teringan). Bila target tidak mungkin dicapai dengan jawaban salah yang sudah ada, aplikasi menjelaskan nilai maksimum yang masih mungkin. Nilai simulasi bukan nilai resmi dan fitur ini tidak menyentuh platform ujian mana pun.

## Struktur proyek

```
app/src/main/java/com/fadrol/ai/
  FadrolApp.kt, AppContainer.kt, MainActivity.kt
  ai/          prompt, mode jawaban, layanan Firebase AI Logic, AiRepository
  network/     klien REST Gemini (API key sendiri)
  ocr/         ML Kit OCR + utilitas gambar
  capture/     MediaProjection, pemilih gambar, penghubung ke service mengambang
  floating/    FloatingService (ikon + panel overlay), panel Compose
  chat/        ChatController bersama (AI Chat dan panel)
  targetscore/ kalkulator, state, UI, parser penilaian AI
  data/        Room (percakapan, pesan) dan repository
  settings/    DataStore, enkripsi API key (Keystore)
  ui/          tema, komponen, layar, navigasi
app/src/debug|release/.../AppCheckInstaller.kt   App Check debug / Play Integrity
app/src/test/                                    unit test Target nilai
docs/                                            AI_SETUP.md, TEST_REPORT.md
```

## Versi dan kompatibilitas

AGP 8.13.2, Gradle 8.13, Kotlin 2.2.21, KSP 2.2.21-2.0.4, Compose BOM 2025.10.01 (Material 3 1.4.0), Room 2.8.4, Firebase BoM 34.18.0. `minSdk 26`, `compileSdk` dan `targetSdk 36`. Kombinasi ini dipilih agar konsisten satu sama lain; versi lebih baru (AGP 9, Kotlin 2.4) tersedia tetapi belum dicoba di proyek ini.

## Keterbatasan yang diketahui

- Belum dikompilasi dan belum diuji di perangkat (lihat laporan pengujian). Kesalahan kompilasi kecil mungkin muncul pada build pertama.
- Keyboard di panel mengambang: panel tidak memakai seluruh tinggi layar supaya tidak tertutup keyboard, tetapi perilaku `adjustResize` pada jendela overlay berbeda antar perangkat. Perlu diuji.
- Android 15 ke atas memungkinkan pengguna memilih membagikan satu aplikasi saja saat tangkap layar. Itu mengikuti sistem.
- Aplikasi yang memakai `FLAG_SECURE` menghasilkan layar hitam. Fadrol mendeteksinya dan menyarankan unggah gambar manual.
- APK yang dipasang manual tidak lolos Play Integrity. Dengan Firebase AI Logic, pakai build debug (token debug App Check) atau jalur API key sendiri. Menurut dokumentasi Firebase per 16 Okt 2026, App Check wajib untuk Firebase AI Logic mulai 2 Nov 2026.
- Pertanyaan lanjutan setelah analisis gambar memakai teks percakapan sebelumnya; gambar lama tidak dikirim ulang.
